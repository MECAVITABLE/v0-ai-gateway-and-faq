import { useEffect, useState } from "react"

export default function NetworkGuard() {
  const [offline, setOffline] = useState(!navigator.onLine)
  const [visible, setVisible] = useState(!navigator.onLine)

  useEffect(() => {
    const goOffline = () => { setOffline(true); setVisible(true) }
    const goOnline = () => {
      setOffline(false)
      setTimeout(() => setVisible(false), 1200)
    }
    window.addEventListener("offline", goOffline)
    window.addEventListener("online", goOnline)
    return () => {
      window.removeEventListener("offline", goOffline)
      window.removeEventListener("online", goOnline)
    }
  }, [])

  if (!visible) return null

  return (
    <div style={{
      position: "fixed",
      inset: 0,
      zIndex: 99999,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      background: "rgba(4,12,4,0.85)",
      backdropFilter: "blur(12px)",
      fontFamily: "Inter, sans-serif",
      padding: 20,
    }}>
      <div style={{
        background: "rgba(8,20,8,0.97)",
        border: "1px solid rgba(255,80,80,0.25)",
        borderRadius: 20,
        padding: "2.5rem 2rem",
        maxWidth: 360,
        width: "100%",
        textAlign: "center",
        boxShadow: "0 0 60px rgba(255,50,50,0.08), 0 20px 60px rgba(0,0,0,0.7)",
        animation: "slideUp 0.3s ease",
      }}>
        {/* Icon */}
        <div style={{
          width: 64,
          height: 64,
          borderRadius: "50%",
          background: "rgba(255,80,80,0.08)",
          border: "1.5px solid rgba(255,80,80,0.2)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          margin: "0 auto 1.5rem",
        }}>
          {offline ? (
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
              <line x1="1" y1="1" x2="23" y2="23" stroke="#ff5050" strokeWidth="2" strokeLinecap="round" />
              <path d="M16.72 11.06A10.94 10.94 0 0 1 19 12.55" stroke="#ff5050" strokeWidth="2" strokeLinecap="round" />
              <path d="M5 12.55a10.94 10.94 0 0 1 5.17-2.39" stroke="#ff5050" strokeWidth="2" strokeLinecap="round" />
              <path d="M10.71 5.05A16 16 0 0 1 22.56 9" stroke="#ff5050" strokeWidth="2" strokeLinecap="round" />
              <path d="M1.42 9a15.91 15.91 0 0 1 4.7-2.88" stroke="#ff5050" strokeWidth="2" strokeLinecap="round" />
              <path d="M8.53 16.11a6 6 0 0 1 6.95 0" stroke="#ff5050" strokeWidth="2" strokeLinecap="round" />
              <circle cx="12" cy="20" r="1" fill="#ff5050" />
            </svg>
          ) : (
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
              <polyline points="20 6 9 17 4 12" stroke="#00ff88" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          )}
        </div>

        <h2 style={{
          fontSize: "1.2rem",
          fontWeight: 700,
          color: offline ? "#ff7070" : "#00ff88",
          marginBottom: "0.5rem",
        }}>
          {offline ? "No Connection" : "Back Online!"}
        </h2>

        <p style={{
          color: "rgba(255,255,255,0.5)",
          fontSize: "0.88rem",
          lineHeight: 1.6,
          marginBottom: offline ? "1.8rem" : 0,
        }}>
          {offline
            ? "Please check your internet connection and try again."
            : "Your connection has been restored."}
        </p>

        {offline && (
          <button
            onClick={() => window.location.reload()}
            style={{
              background: "linear-gradient(135deg, #00c864, #00ff88)",
              border: "none",
              borderRadius: 10,
              color: "#050805",
              fontWeight: 700,
              fontSize: "0.88rem",
              padding: "0.75rem 2rem",
              cursor: "pointer",
              letterSpacing: "0.05em",
            }}
          >
            Try Again
          </button>
        )}
      </div>

      <style>{`
        @keyframes slideUp {
          from { transform: translateY(30px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
      `}</style>
    </div>
  )
}
