import { useEffect, useState } from "react"

const PlantGrowth = () => {
  const [cycle, setCycle] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setCycle(c => c + 1)
    }, 7000)
    return () => clearInterval(interval)
  }, [])

  return (
    <section className="plant-growth-section">
      <div className="plant-box">
        <div className="plant-badge plant-badge-tl">
          <span className="plant-badge-label">MODE</span>
          <span className="plant-badge-value">HALAL</span>
        </div>
        <div className="plant-badge plant-badge-tr">
          <span className="plant-badge-label">MARKET</span>
          <span className="plant-badge-value">STOCKS</span>
        </div>
        <div className="plant-badge plant-badge-bl">
          <span className="plant-badge-label">UPTIME</span>
          <span className="plant-badge-value">24/7</span>
        </div>
        <div className="plant-badge plant-badge-br">
          <span className="plant-badge-label">DATA</span>
          <span className="plant-badge-value">Live <span className="live-dot" /></span>
        </div>

        <div className="plant-glow-bg" />
        <svg key={cycle} className="plant-svg" viewBox="0 0 200 300" fill="none" xmlns="http://www.w3.org/2000/svg">
          <line x1="100" y1="280" x2="100" y2="80" className="plant-svg-stem" />
          <line x1="100" y1="220" x2="145" y2="185" className="plant-svg-leaf plant-svg-leaf-r1" />
          <line x1="100" y1="180" x2="140" y2="148" className="plant-svg-leaf plant-svg-leaf-r2" />
          <line x1="100" y1="145" x2="132" y2="118" className="plant-svg-leaf plant-svg-leaf-r3" />
          <line x1="100" y1="115" x2="125" y2="95" className="plant-svg-leaf plant-svg-leaf-r4" />
          <line x1="100" y1="200" x2="55" y2="165" className="plant-svg-leaf plant-svg-leaf-l1" />
          <line x1="100" y1="162" x2="60" y2="132" className="plant-svg-leaf plant-svg-leaf-l2" />
          <line x1="100" y1="130" x2="68" y2="105" className="plant-svg-leaf plant-svg-leaf-l3" />
          <circle cx="100" cy="75" r="6" className="plant-svg-bud" />
        </svg>
      </div>
    </section>
  )
}

export default PlantGrowth
