import { useState, useEffect, useRef } from "react"
import { sendChat, FOUNDERS_BLURB, PRODUCT_BLURB } from "@/lib/chat"

interface FAQItem {
  id: number
  question: string
  answer: string
  category: string
}

const faqData: FAQItem[] = [
  { id: 1, question: "Who is the creator of MIFTORA EA?", answer: "MIFTORA EA was created by three friends from Kerala, India: Muhammed Najih (@m.najey), Muhammed KP (@mhdkpy) and Aslam (@m_asluu_t.x).", category: "About" },
  { id: 111, question: "Who is Aslam?", answer: "Aslam is one of the creators of MIFTORA EA, together with Muhammed Najih and Muhammed KP. You can find him on Instagram at @m_asluu_t.x.", category: "About" },
  { id: 2, question: "What is MIFTORA EA?", answer: "MIFTORA EA is a halal EA hosting service for the stock market. You bring your own trading bot (Expert Advisor) and your own broker account, and we run the EA for you on secure, always-on servers.", category: "Beginner" },
  { id: 3, question: "How do I start with MIFTORA EA?", answer: "Open a cash account with a Shariah-compliant stock broker, fund it with an amount you can afford to lose, then contact our team on Instagram to set up your EA on our hosting.", category: "Beginner" },
  { id: 4, question: "Is MIFTORA EA suitable for beginners?", answer: "Yes. We handle the server setup and keep your EA running, so you do not need technical knowledge about servers. Still, understand the risks of stock trading before you start.", category: "Beginner" },
  { id: 5, question: "Do I need trading experience to use MIFTORA EA?", answer: "No server or hosting experience is needed. We set up and run your EA. It helps to understand the basics of how your EA trades, so you know what to expect.", category: "Beginner" },
  { id: 6, question: "What is EA hosting?", answer: "EA hosting means your trading bot runs on our secure servers instead of your own computer. It stays online 24/7, so it never stops because your PC, internet or power goes down.", category: "Beginner" },
  { id: 7, question: "How does automated trading work?", answer: "Automated trading uses an algorithm (your EA) to place trades based on predefined rules, without manual intervention. It trades during stock market hours.", category: "Beginner" },
  { id: 8, question: "What is an Expert Advisor (EA)?", answer: "An Expert Advisor is an automated trading program that places trades on your behalf based on specific rules and strategies.", category: "Beginner" },
  { id: 9, question: "Is MIFTORA EA copy trading?", answer: "No. MIFTORA EA is not copy trading and not forex. It is a hosting service that runs your own EA on your own stock broker account.", category: "Beginner" },
  { id: 10, question: "Can I monitor my EA from my phone?", answer: "Yes. You can check your account in your broker's mobile app, and review your EA's logs and reports from any device with internet access.", category: "Beginner" },
  { id: 11, question: "What makes MIFTORA EA halal?", answer: "We follow a halal approach: cash (non-margin) accounts only, no leverage, no borrowing, no interest (riba) or swap fees, no short selling, and only Shariah-screened stocks.", category: "Halal" },
  { id: 12, question: "Which stocks can the EA trade?", answer: "Only stocks that pass Shariah screening. That means no companies in alcohol, gambling, pork, adult content, or conventional interest-based finance, and with acceptable debt and interest-income levels.", category: "Halal" },
  { id: 13, question: "Why no leverage?", answer: "Leverage means borrowing money to trade, usually with interest or fees attached, which is not allowed in the halal approach. All trades are made with your own cash.", category: "Halal" },
  { id: 14, question: "Why is short selling not allowed?", answer: "Short selling means selling shares you do not own, which many scholars consider impermissible. Your EA only buys shares and sells shares it holds.", category: "Halal" },
  { id: 15, question: "What is riba and how do you avoid it?", answer: "Riba is interest. We avoid it by using cash accounts only: no margin loans, no overnight swap or financing fees, and no interest-bearing products.", category: "Halal" },
  { id: 16, question: "Is this a fatwa or religious ruling?", answer: "No. We explain the halal approach we follow, but we do not issue religious rulings. If you want certainty, please confirm with a qualified scholar.", category: "Halal" },
  { id: 17, question: "Which broker should I use?", answer: "Use a regulated stock broker that offers cash accounts without margin or interest, and ideally offers Shariah-compliant (Islamic) accounts. Message our team for guidance.", category: "Account Setup" },
  { id: 18, question: "What documents do I need to open a broker account?", answer: "Usually a government-issued ID (passport or national ID) and proof of address (utility bill or bank statement). Requirements depend on your broker and country.", category: "Account Setup" },
  { id: 19, question: "How long does account verification take?", answer: "It depends on your broker. Many verify accounts within a few days, sometimes faster.", category: "Account Setup" },
  { id: 20, question: "Can I use an existing broker account?", answer: "Yes, as long as it is a cash account without margin or interest and works with your EA. Contact us and we will check it with you.", category: "Account Setup" },
  { id: 21, question: "Can my own EA be hosted?", answer: "Yes. You bring your own EA and we host it. Share the details with our team on Instagram and we will confirm compatibility and set it up.", category: "Account Setup" },
  { id: 22, question: "Can I host more than one EA?", answer: "Yes, you can host multiple EAs or accounts. Contact our team to discuss your setup.", category: "Account Setup" },
  { id: 23, question: "Do you have access to my money?", answer: "No. Your funds stay in your own broker account and we never hold your money. Where your broker supports it, we use trade-only access so withdrawals are not possible from the server.", category: "Account Setup" },
  { id: 24, question: "How do I change my EA or its settings?", answer: "Message our team and we will update the configuration on your hosted EA.", category: "Account Setup" },
  { id: 25, question: "What returns can I expect?", answer: "No returns can be promised. Results depend on your EA's strategy and on market conditions. Stocks can go up and down.", category: "Profits" },
  { id: 26, question: "Are the profits guaranteed?", answer: "No. No investment can guarantee profits. Stock trading involves risk, and you can lose part or all of your capital.", category: "Profits" },
  { id: 27, question: "What does MIFTORA EA charge?", answer: "Pricing for hosting is shared directly by our team. Message us on Instagram for current details.", category: "Profits" },
  { id: 28, question: "Do you take a share of my profits?", answer: "Please check the current terms with our team before you start, so everything is clear and agreed in advance.", category: "Profits" },
  { id: 29, question: "What is compound growth?", answer: "Compound growth means profits are reinvested to generate additional returns over time. It only works if your EA is actually profitable, and it also compounds losses.", category: "Profits" },
  { id: 30, question: "When will I start seeing results?", answer: "Your EA starts running as soon as it is set up. How soon results appear depends on its strategy and the market.", category: "Profits" },
  { id: 31, question: "What risk management should my EA use?", answer: "We recommend EAs that use stop-losses, small position sizes, and diversification across several stocks. Never put money in that you cannot afford to lose.", category: "Risk" },
  { id: 32, question: "Can I lose all my money?", answer: "Yes, it is possible. All trading carries risk. Only invest what you can afford to lose.", category: "Risk" },
  { id: 33, question: "What is a stop-loss?", answer: "A stop-loss is an automatic order that closes a trade at a predetermined price to limit potential losses.", category: "Risk" },
  { id: 34, question: "How much should I invest?", answer: "Only invest money you can afford to lose. Start small and scale up only when you are comfortable.", category: "Risk" },
  { id: 35, question: "Is stock trading risky?", answer: "Yes. Stock prices change with company news, the economy and market sentiment. Using cash only (no leverage) removes borrowing risk, but price risk remains.", category: "Risk" },
  { id: 36, question: "What happens during volatile markets?", answer: "Prices can move quickly and your EA may take losses. This is why risk limits and position sizing are important.", category: "Risk" },
  { id: 37, question: "What is position sizing?", answer: "Position sizing decides how much capital goes into each trade, a key part of risk management.", category: "Risk" },
  { id: 38, question: "What if the server goes down?", answer: "Our servers are built for reliability, but no system is perfect. Your open positions stay in your broker account, and you can always manage them directly with your broker.", category: "Risk" },
  { id: 39, question: "How do I withdraw my money?", answer: "Withdraw directly from your broker account using your broker's withdrawal options. Your money is always in your own account.", category: "Withdrawals" },
  { id: 40, question: "Can I stop the EA at any time?", answer: "Yes. Contact our team to pause or stop your hosted EA at any time. You can also close your positions directly with your broker.", category: "Withdrawals" },
  { id: 41, question: "Can I withdraw while the EA is running?", answer: "Yes, but reducing your balance can affect how your EA trades. Tell our team if you plan a large withdrawal.", category: "Withdrawals" },
  { id: 42, question: "How long do withdrawals take?", answer: "It depends on your broker and payment method, usually from minutes to a few working days.", category: "Withdrawals" },
  { id: 43, question: "Are there withdrawal fees?", answer: "Fees are set by your broker. Check your broker's fee schedule for your payment method.", category: "Withdrawals" },
  { id: 44, question: "Can I see what my EA is doing?", answer: "Yes. You can see every trade in your broker account, and we provide logs and reports so you can follow your EA's activity.", category: "Transparency" },
  { id: 45, question: "How is performance verified?", answer: "Your broker statements are the source of truth. Compare them with your EA's logs and reports to confirm results.", category: "Transparency" },
  { id: 46, question: "Why is transparency important to you?", answer: "Because you should always know what is happening with your money and whether it follows the halal rules we promise.", category: "Transparency" },
  { id: 91, question: "How do I get support?", answer: "Reach out to us on Instagram \u2014 DM @m.najey (Najih), @mhdkpy (Muhammed KP) or @m_asluu_t.x (Aslam). The team is happy to help!", category: "Support" },
  { id: 92, question: "What is the response time for support?", answer: "We aim to respond to all inquiries within 24 hours, often much faster.", category: "Support" },
  { id: 100, question: "How do I stay updated?", answer: "Follow the creators on Instagram \u2014 @m.najey (Najih), @mhdkpy (Muhammed KP) and @m_asluu_t.x (Aslam) \u2014 for the latest updates and announcements.", category: "Support" },
  { id: 110, question: "Can I use MIFTORA EA from any country?", answer: "It depends on whether a Shariah-compliant stock broker serves your country. Ask our team and we will help you check.", category: "Beginner" },
]

const SYSTEM_PROMPT = `You are Dr. Rabbit, the AI assistant built by the founders of MIFTORA EA to help users get information and get started.

${FOUNDERS_BLURB}

${PRODUCT_BLURB}

Tone rules:
- Be helpful, clear, and professional.
- Do NOT overuse the user's name. Only use it if they have introduced themselves.
- Do NOT pretend to have a close personal relationship with the user.
- Use 1 emoji per message max, only when it adds clarity.
- Keep answers concise. If asked something unrelated to MIFTORA EA or halal stock trading, politely redirect.`

interface Message {
  role: "user" | "assistant"
  content: string
}

function AIChatTab() {
  const [messages, setMessages] = useState<Message[]>([
    { role: "assistant", content: "Hey! I'm Dr. Rabbit 🐰 — the AI assistant built by the MIFTORA EA founders. Ask me anything about halal EA hosting for stocks, how to get started, or the founders." }
  ])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const sendMessage = async () => {
    if (!input.trim() || isLoading) return

    const userMessage: Message = { role: "user", content: input.trim() }
    setMessages(prev => [...prev, userMessage])
    setInput("")
    setIsLoading(true)

    try {
      const conversationHistory = [...messages, userMessage]

      const assistantText =
        (await sendChat({
          system: SYSTEM_PROMPT,
          messages: conversationHistory,
          maxTokens: 350,
          temperature: 0.7,
        })) || "Sorry, I couldn't process that. Please try again!"

      setMessages(prev => [...prev, { role: "assistant", content: assistantText }])
    } catch (error) {
      console.error("Chat error:", error)
      setMessages(prev => [...prev, {
        role: "assistant",
        content: "Sorry, something went wrong. Please try again in a moment."
      }])
    } finally {
      setIsLoading(false)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      sendMessage()
    }
  }

  return (
    <div className="chatbot-tab-content">
      <div className="chatbot-messages">
        {messages.map((msg, i) => (
          <div key={i} className={`chatbot-msg chatbot-msg-${msg.role}`}>
            {msg.role === "assistant" && (
              <span className="chatbot-avatar" style={{ fontSize: "1rem" }}>🐰</span>
            )}
            <div className="chatbot-bubble">{msg.content}</div>
          </div>
        ))}
        {isLoading && (
          <div className="chatbot-msg chatbot-msg-assistant">
            <span className="chatbot-avatar" style={{ fontSize: "1rem" }}>🐰</span>
            <div className="chatbot-bubble chatbot-typing">
              <span /><span /><span />
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="chatbot-input-area">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Ask Dr. Rabbit anything..."
          disabled={isLoading}
          className="chatbot-input"
        />
        <button
          onClick={sendMessage}
          disabled={isLoading || !input.trim()}
          className="chatbot-send"
        >
          <span className="material-icons-outlined">send</span>
        </button>
      </div>
    </div>
  )
}

export default function HelpFAQ() {
  const [isOpen, setIsOpen] = useState(false)
  const [activeTab, setActiveTab] = useState<"faq" | "ai">("faq")
  const [searchQuery, setSearchQuery] = useState("")
  const [openQuestion, setOpenQuestion] = useState<number | null>(null)
  const [showTyping, setShowTyping] = useState(false)
  const [showCreators, setShowCreators] = useState(false)
  const panelRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (isOpen) {
      setShowTyping(true)
      const timer = setTimeout(() => setShowTyping(false), 1500)
      return () => clearTimeout(timer)
    }
  }, [isOpen])

  const filteredFAQs = faqData.filter(faq => {
    const matchesSearch = faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          faq.answer.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesSearch
  })

  const handleQuestionClick = (id: number) => {
    setOpenQuestion(openQuestion === id ? null : id)
  }

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="help-btn"
        aria-label="Open Help & FAQ"
      >
        <span className="material-icons-outlined">chat_bubble_outline</span>
      </button>

      {isOpen && (
        <div className="faq-overlay" onClick={() => setIsOpen(false)}>
          <div
            ref={panelRef}
            className="faq-panel"
            onClick={e => e.stopPropagation()}
          >
            <div className="panel-particles">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="panel-particle" style={{
                  left: `${10 + i * 12}%`,
                  animationDelay: `${i * 0.5}s`
                }} />
              ))}
            </div>

            <div className="faq-header">
              <div className="faq-header-content">
                {activeTab === "ai" ? (
                  <span style={{ fontSize: "1.5rem", lineHeight: 1 }}>🐰</span>
                ) : (
                  <span className="material-icons-outlined faq-header-icon">support_agent</span>
                )}
                <div>
                  <h3>{activeTab === "ai" ? "Dr. Rabbit" : "Help & FAQ"}</h3>
                  <p>{activeTab === "ai" ? "AI Advisor — Ask Anything" : "Find answers instantly"}</p>
                </div>
              </div>
              <button onClick={() => setIsOpen(false)} className="faq-close">
                <span className="material-icons-outlined">close</span>
              </button>
            </div>

            <div className="faq-tabs">
              <button
                className={`faq-tab-btn ${activeTab === "faq" ? "active" : ""}`}
                onClick={() => setActiveTab("faq")}
              >
                <span className="material-icons-outlined">quiz</span>
                FAQ
              </button>
              <button
                className={`faq-tab-btn ${activeTab === "ai" ? "active" : ""}`}
                onClick={() => setActiveTab("ai")}
              >
                <span style={{ fontSize: "0.95rem" }}>🐰</span>
                Dr. Rabbit
              </button>
            </div>

            {activeTab === "faq" ? (
              <>
                {showTyping && (
                  <div className="typing-indicator">
                    <span className="material-icons-outlined">smart_toy</span>
                    <div className="typing-dots">
                      <span></span>
                      <span></span>
                      <span></span>
                    </div>
                    <span className="typing-text">Loading answers...</span>
                  </div>
                )}

                <div className="faq-search">
                  <span className="material-icons-outlined search-icon">search</span>
                  <input
                    type="text"
                    placeholder="Search your question..."
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    className="search-input"
                  />
                  {searchQuery && (
                    <button onClick={() => setSearchQuery("")} className="search-clear">
                      <span className="material-icons-outlined">close</span>
                    </button>
                  )}
                </div>

                <div className="results-count">
                  <span className="material-icons-outlined">quiz</span>
                  {filteredFAQs.length} questions found
                </div>

                <div className="faq-list">
                  {filteredFAQs.length > 0 ? filteredFAQs.map(faq => (
                    <div
                      key={faq.id}
                      className={`faq-item ${openQuestion === faq.id ? "open" : ""}`}
                    >
                      <button
                        onClick={() => handleQuestionClick(faq.id)}
                        className="faq-question"
                      >
                        <div className="question-content">
                          <span className="question-number">#{faq.id}</span>
                          <span className="question-text">{faq.question}</span>
                        </div>
                        <span className="material-icons-outlined expand-icon">
                          {openQuestion === faq.id ? "expand_less" : "expand_more"}
                        </span>
                      </button>
                      <div className={`faq-answer ${openQuestion === faq.id ? "show" : ""}`}>
                        <div className="answer-content">
                          <span className="category-tag">{faq.category}</span>
                          <p>
                            {faq.answer.includes("instagram.com") ? (
                              <>
                                {faq.answer.split("https://")[0]}
                                <a
                                  href="https://instagram.com/m.najey"
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="answer-link"
                                >
                                  <span className="material-icons-outlined">open_in_new</span>
                                  @m.najey
                                </a>
                              </>
                            ) : faq.answer}
                          </p>
                        </div>
                      </div>
                    </div>
                  )) : (
                    <div className="no-results">
                      <span className="material-icons-outlined">search_off</span>
                      <p>No results found</p>
                      <span>Try a different search term</span>
                    </div>
                  )}
                </div>

                <div className="faq-footer">
                  <p style={{ marginBottom: "12px" }}>Built by three friends from Kerala 🌿</p>
                  <div style={{ position: "relative", display: "inline-block" }}>
                    <button
                      onClick={() => setShowCreators(!showCreators)}
                      style={{ display: "flex", alignItems: "center", gap: "7px", background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.15)", borderRadius: "999px", padding: "8px 18px", color: "rgba(255,255,255,0.8)", fontSize: "0.8rem", fontWeight: 600, cursor: "pointer", letterSpacing: "0.03em" }}
                    >
                      <span style={{ fontSize: "0.9rem" }}>✌️</span> Creators
                    </button>
                    {showCreators && (
                      <div style={{ position: "absolute", bottom: "calc(100% + 10px)", left: "50%", transform: "translateX(-50%)", background: "rgba(10,20,15,0.97)", border: "1px solid rgba(0,255,128,0.18)", borderRadius: "16px", padding: "12px", display: "flex", gap: "8px", flexDirection: "column", minWidth: "200px", boxShadow: "0 8px 32px rgba(0,0,0,0.5)", zIndex: 100 }}>
                        <a href="https://instagram.com/m.najey" target="_blank" rel="noopener noreferrer"
                          style={{ display: "flex", alignItems: "center", gap: "9px", background: "rgba(0,255,128,0.07)", border: "1px solid rgba(0,255,128,0.2)", borderRadius: "10px", padding: "8px 12px", color: "#00ff80", textDecoration: "none", fontSize: "0.78rem" }}>
                          <span style={{ fontWeight: 800, background: "rgba(0,255,128,0.2)", borderRadius: "50%", width: "26px", height: "26px", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.7rem", flexShrink: 0 }}>N</span>
                          <span style={{ textAlign: "left" }}>
                            <div style={{ fontWeight: 700, lineHeight: 1.3 }}>Najih</div>
                            <div style={{ opacity: 0.6, fontSize: "0.68rem" }}>@m.najey</div>
                          </span>
                        </a>
                        <a href="https://instagram.com/mhdkpy" target="_blank" rel="noopener noreferrer"
                          style={{ display: "flex", alignItems: "center", gap: "9px", background: "rgba(120,160,255,0.07)", border: "1px solid rgba(120,160,255,0.2)", borderRadius: "10px", padding: "8px 12px", color: "#90b4ff", textDecoration: "none", fontSize: "0.78rem" }}>
                          <span style={{ fontWeight: 800, background: "rgba(120,160,255,0.2)", borderRadius: "50%", width: "26px", height: "26px", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.7rem", flexShrink: 0 }}>K</span>
                          <span style={{ textAlign: "left" }}>
                            <div style={{ fontWeight: 700, lineHeight: 1.3 }}>Muhammed KP</div>
                            <div style={{ opacity: 0.6, fontSize: "0.68rem" }}>@mhdkpy</div>
                          </span>
                        </a>
                        <a href="https://instagram.com/m_asluu_t.x" target="_blank" rel="noopener noreferrer"
                          style={{ display: "flex", alignItems: "center", gap: "9px", background: "rgba(255,170,90,0.07)", border: "1px solid rgba(255,170,90,0.22)", borderRadius: "10px", padding: "8px 12px", color: "#ffb870", textDecoration: "none", fontSize: "0.78rem" }}>
                          <span style={{ fontWeight: 800, background: "rgba(255,170,90,0.2)", borderRadius: "50%", width: "26px", height: "26px", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.7rem", flexShrink: 0 }}>A</span>
                          <span style={{ textAlign: "left" }}>
                            <div style={{ fontWeight: 700, lineHeight: 1.3 }}>Aslam</div>
                            <div style={{ opacity: 0.6, fontSize: "0.68rem" }}>@m_asluu_t.x</div>
                          </span>
                        </a>
                      </div>
                    )}
                  </div>
                </div>
              </>
            ) : (
              <AIChatTab />
            )}
          </div>
        </div>
      )}
    </>
  )
}
