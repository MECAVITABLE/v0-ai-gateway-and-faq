const TRADES = [
  { pair: "AAPL",  dir: "BUY",  profit: "+$47.20", pips: "+2.4%", time: "2s ago"  },
  { pair: "MSFT",  dir: "BUY",  profit: "+$23.10", pips: "+1.1%", time: "14s ago" },
  { pair: "NVDA",  dir: "SELL", profit: "+$61.40", pips: "+3.2%", time: "31s ago" },
  { pair: "GOOGL", dir: "BUY",  profit: "+$34.80", pips: "+1.8%", time: "58s ago" },
  { pair: "ADBE",  dir: "SELL", profit: "+$88.60", pips: "+4.1%", time: "1m ago"  },
  { pair: "CSCO",  dir: "BUY",  profit: "+$19.40", pips: "+0.9%", time: "2m ago"  },
  { pair: "TSM",   dir: "BUY",  profit: "+$42.90", pips: "+2.3%", time: "3m ago"  },
  { pair: "ASML",  dir: "SELL", profit: "+$27.30", pips: "+1.6%", time: "4m ago"  },
  { pair: "INTU",  dir: "BUY",  profit: "+$103.5", pips: "+4.8%", time: "5m ago"  },
  { pair: "AMAT",  dir: "SELL", profit: "+$16.70", pips: "+0.8%", time: "6m ago"  },
  { pair: "NFLX",  dir: "BUY",  profit: "+$11.20", pips: "+0.6%", time: "7m ago"  },
  { pair: "LRCX",  dir: "SELL", profit: "+$55.80", pips: "+2.7%", time: "9m ago"  },
]

export default function TradeFeed() {
  const items = [...TRADES, ...TRADES]

  return (
    <div className="trade-feed-bar">
      <div className="trade-feed-label">
        <span className="live-dot" />
        LIVE
      </div>
      <div className="trade-feed-track-wrapper">
        <div className="trade-feed-track">
          {items.map((t, i) => (
            <div className="trade-feed-item" key={i}>
              <span className={`trade-feed-dir ${t.dir === "BUY" ? "buy" : "sell"}`}>
                {t.dir}
              </span>
              <span className="trade-feed-pair">{t.pair}</span>
              <span className="trade-feed-profit">{t.profit}</span>
              <span className="trade-feed-pips">{t.pips}</span>
              <span className="trade-feed-time">{t.time}</span>
              <span className="trade-feed-sep">·</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
