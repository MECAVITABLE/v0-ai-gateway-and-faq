import { useState, useEffect, useRef, useCallback } from "react"
import { sendChat, FOUNDERS_BLURB, PRODUCT_BLURB } from "@/lib/chat"

const DOCTOR_SYSTEM = `You are Dr. Rabbit, the AI advisor built by the founders of MIFTORA EA — a halal EA hosting service for the stock market.

The user just clicked "Not really" on an investment quiz. They have doubts. Your job is to calmly and genuinely address their concerns and help them see why MIFTORA EA is a simple, halal, low-effort way to start.

${FOUNDERS_BLURB}

${PRODUCT_BLURB}

Rules:
- Speak in simple, plain English. No jargon.
- Keep it very short: 1-2 sentences max per reply.
- Be warm and honest — not salesy, not over-familiar.
- Do NOT overuse the user's name. Only use it if they have told you their name.
- Use 1 emoji per message at most, only when it adds clarity.
- If they ask about risk, be honest: no investment is 100% safe, stocks can lose value, so only invest what you can afford to lose.
- End every reply with a gentle nudge toward hosting an EA with MIFTORA EA.`

interface DoctorMsg { role: "user" | "assistant"; content: string }

function ConsultDoctorOverlay({ onBack, cursorRef }: { onBack: () => void; cursorRef: React.RefObject<HTMLDivElement | null> }) {
  const [msgs, setMsgs] = useState<DoctorMsg[]>([
    { role: "assistant", content: "Hey, I'm Dr. Rabbit. Something made you hesitate — what's on your mind? 🐰" }
  ])
  const [input, setInput] = useState("")
  const [loading, setLoading] = useState(false)
  const bottomRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [msgs])

  const send = useCallback(async (text?: string) => {
    const content = (text ?? input).trim()
    if (!content || loading) return
    const userMsg: DoctorMsg = { role: "user", content }
    setMsgs(p => [...p, userMsg])
    setInput("")
    setLoading(true)
    try {
      const reply = (await sendChat({
        system: DOCTOR_SYSTEM,
        messages: [...msgs, userMsg],
        maxTokens: 180,
        temperature: 0.8,
      })) || "Something went wrong on my end. Please try again."
      setMsgs(p => [...p, { role: "assistant", content: reply }])
    } catch {
      setMsgs(p => [...p, { role: "assistant", content: "Connection issue. Please try again in a moment." }])
    } finally {
      setLoading(false)
    }
  }, [input, loading, msgs])

  const [chatOpen, setChatOpen] = useState(true)

  return (
    <div style={{
      position: "fixed",
      inset: 0,
      zIndex: 9998,
      background: "#080808",
      fontFamily: "Inter, sans-serif",
      cursor: "none",
    }}>
      <div ref={cursorRef} style={{
        position: "fixed", top: 0, left: 0, width: 8, height: 8,
        borderRadius: "50%", background: "#ffffff", pointerEvents: "none",
        zIndex: 99999, willChange: "transform",
      }} />

      <div style={{
        height: "100vh",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        textAlign: "center",
        padding: "28px 24px 20px",
        position: "relative",
      }}>
        <div style={{
          position: "absolute", inset: 0,
          background: "radial-gradient(ellipse at 50% 100%, rgba(80,0,0,0.12) 0%, transparent 70%)",
          pointerEvents: "none",
        }} />

        <div style={{ fontSize: "clamp(3rem, 10vw, 5rem)", marginBottom: 12 }}>🚫</div>

        <h2 style={{
          fontSize: "clamp(1.4rem, 4vw, 2rem)",
          fontWeight: 800,
          color: "#fff",
          letterSpacing: "-0.02em",
          marginBottom: 10,
          lineHeight: 1.2,
        }}>
          Doubt is normal.<br />
          <span style={{ color: "rgba(255,255,255,0.45)", fontWeight: 500, fontSize: "0.75em" }}>
            But staying stuck isn't an option.
          </span>
        </h2>

        <p style={{
          color: "rgba(255,255,255,0.35)",
          fontSize: "0.9rem",
          maxWidth: 340,
          margin: "0 auto 28px",
          lineHeight: 1.6,
        }}>
          Let Dr. Rabbit walk you through it. Ask anything.
        </p>

        {chatOpen && (
          <div style={{
            width: "100%",
            maxWidth: 440,
            background: "rgba(255,255,255,0.03)",
            border: "1px solid rgba(255,255,255,0.07)",
            borderRadius: 20,
            overflow: "hidden",
            display: "flex",
            flexDirection: "column",
            maxHeight: "40vh",
          }}>
            <div style={{
              flex: 1,
              overflowY: "auto",
              padding: "16px 16px 8px",
              display: "flex",
              flexDirection: "column",
              gap: 10,
            }}>
              {msgs.map((m, i) => (
                <div key={i} style={{
                  display: "flex",
                  justifyContent: m.role === "user" ? "flex-end" : "flex-start",
                }}>
                  <div style={{
                    maxWidth: "82%",
                    padding: "9px 13px",
                    borderRadius: m.role === "user" ? "14px 14px 4px 14px" : "14px 14px 14px 4px",
                    background: m.role === "user"
                      ? "rgba(0,255,136,0.12)"
                      : "rgba(255,255,255,0.05)",
                    color: m.role === "user" ? "#00ff88" : "rgba(255,255,255,0.75)",
                    fontSize: "0.82rem",
                    lineHeight: 1.5,
                    border: m.role === "user"
                      ? "1px solid rgba(0,255,136,0.2)"
                      : "1px solid rgba(255,255,255,0.06)",
                    textAlign: "left",
                  }}>
                    {m.content}
                  </div>
                </div>
              ))}
              {loading && (
                <div style={{ display: "flex", justifyContent: "flex-start" }}>
                  <div style={{
                    padding: "9px 16px",
                    borderRadius: "14px 14px 14px 4px",
                    background: "rgba(255,255,255,0.05)",
                    border: "1px solid rgba(255,255,255,0.06)",
                    color: "rgba(255,255,255,0.3)",
                    fontSize: "0.82rem",
                  }}>
                    thinking...
                  </div>
                </div>
              )}
              <div ref={bottomRef} />
            </div>
            <div style={{
              padding: "10px 12px",
              borderTop: "1px solid rgba(255,255,255,0.05)",
              display: "flex",
              gap: 8,
            }}>
              <input
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={e => e.key === "Enter" && send()}
                placeholder="Ask Dr. Rabbit..."
                style={{
                  flex: 1,
                  background: "rgba(255,255,255,0.05)",
                  border: "1px solid rgba(255,255,255,0.1)",
                  borderRadius: 10,
                  color: "#fff",
                  fontSize: "0.82rem",
                  padding: "8px 12px",
                  outline: "none",
                }}
              />
              <button
                onClick={() => send()}
                disabled={loading || !input.trim()}
                style={{
                  background: "rgba(0,255,136,0.15)",
                  border: "1px solid rgba(0,255,136,0.25)",
                  borderRadius: 10,
                  color: "#00ff88",
                  padding: "8px 14px",
                  fontSize: "0.8rem",
                  cursor: "pointer",
                  fontWeight: 700,
                  opacity: loading || !input.trim() ? 0.4 : 1,
                }}
              >
                Send
              </button>
            </div>
          </div>
        )}

        <div style={{ display: "flex", gap: 10, marginTop: 20, flexWrap: "wrap", justifyContent: "center" }}>
          <button
            onClick={onBack}
            style={{
              background: "rgba(0,255,136,0.1)",
              border: "1px solid rgba(0,255,136,0.25)",
              borderRadius: 12,
              color: "#00ff88",
              fontWeight: 700,
              fontSize: "0.85rem",
              padding: "10px 22px",
              cursor: "pointer",
              letterSpacing: "0.03em",
            }}
          >
            ← I changed my mind
          </button>
          <button
            onClick={() => setChatOpen(o => !o)}
            style={{
              background: "rgba(255,255,255,0.05)",
              border: "1px solid rgba(255,255,255,0.1)",
              borderRadius: 12,
              color: "rgba(255,255,255,0.4)",
              fontWeight: 600,
              fontSize: "0.85rem",
              padding: "10px 22px",
              cursor: "pointer",
            }}
          >
            {chatOpen ? "Hide chat" : "Chat with Dr. Rabbit"}
          </button>
        </div>
      </div>

      <style>{`
        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  )
}

interface OnboardingQuizProps {
  onComplete: () => void
}

const QUESTION = {
  headline: "Wanna break your bloodline?",
  sub: "Right now, someone in your family is waiting for you to be the one who changes everything. Not next year. Not when you're 'ready'. Today — one decision is all it takes.",
}

export default function OnboardingQuiz({ onComplete }: OnboardingQuizProps) {
  const [rejected, setRejected] = useState(false)
  const [animating, setAnimating] = useState(false)

  const dotRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const move = (e: MouseEvent) => {
      if (dotRef.current) {
        dotRef.current.style.transform = `translate(${e.clientX - 4}px, ${e.clientY - 4}px)`
      }
    }
    window.addEventListener("mousemove", move)
    return () => window.removeEventListener("mousemove", move)
  }, [])

  const handleYes = () => {
    if (animating) return
    setAnimating(true)
    setTimeout(() => {
      onComplete()
    }, 350)
  }

  const handleNo = () => {
    if (animating) return
    setRejected(true)
  }

  if (rejected) {
    return <ConsultDoctorOverlay onBack={() => setRejected(false)} cursorRef={dotRef} />
  }

  return (
    <div className="quiz-screen" style={{
      position: "fixed",
      inset: 0,
      zIndex: 9998,
      background: "#040c04",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      fontFamily: "Inter, sans-serif",
      padding: 24,
      textAlign: "center",
      cursor: "none",
    }}>
      <div ref={dotRef} style={{
        position: "fixed",
        top: 0,
        left: 0,
        width: 8,
        height: 8,
        borderRadius: "50%",
        background: "#ffffff",
        pointerEvents: "none",
        zIndex: 99999,
        willChange: "transform",
      }} />

      <div style={{
        position: "absolute",
        width: 600,
        height: 600,
        borderRadius: "50%",
        background: "radial-gradient(circle, rgba(0,255,136,0.07) 0%, transparent 70%)",
        pointerEvents: "none",
      }} />

      <button
        onClick={onComplete}
        style={{
          position: "absolute",
          top: 20,
          left: 20,
          background: "transparent",
          border: "none",
          color: "rgba(255,255,255,0.2)",
          fontSize: "0.75rem",
          letterSpacing: "0.12em",
          cursor: "pointer",
          padding: "6px 10px",
          borderRadius: 6,
          textTransform: "uppercase",
          zIndex: 10,
          transition: "color 0.2s",
        }}
        onMouseEnter={e => (e.currentTarget.style.color = "rgba(255,255,255,0.45)")}
        onMouseLeave={e => (e.currentTarget.style.color = "rgba(255,255,255,0.2)")}
      >
        Skip →
      </button>

      <div
        style={{
          position: "relative",
          zIndex: 1,
          maxWidth: 520,
          width: "100%",
          animation: animating ? "slideOut 0.35s ease forwards" : "slideIn 0.55s cubic-bezier(0.22,1,0.36,1)",
        }}
      >
        <div style={{
          display: "inline-flex",
          alignItems: "center",
          gap: 6,
          background: "rgba(0,255,136,0.08)",
          border: "1px solid rgba(0,255,136,0.18)",
          borderRadius: 999,
          padding: "5px 14px",
          marginBottom: 28,
          color: "rgba(0,255,136,0.7)",
          fontSize: "0.7rem",
          letterSpacing: "0.2em",
          textTransform: "uppercase",
          fontWeight: 700,
        }}>
          <span style={{ width: 6, height: 6, borderRadius: "50%", background: "#00ff88", animation: "pulse 1.5s infinite" }} />
          Your moment is now
        </div>

        <h1 style={{
          fontSize: "clamp(2rem, 6vw, 3.2rem)",
          fontWeight: 900,
          color: "#fff",
          lineHeight: 1.1,
          marginBottom: "1.2rem",
          letterSpacing: "-0.03em",
        }}>
          {QUESTION.headline}
        </h1>

        <p style={{
          color: "rgba(255,255,255,0.5)",
          fontSize: "clamp(0.9rem, 2.5vw, 1.05rem)",
          lineHeight: 1.75,
          maxWidth: 420,
          margin: "0 auto 52px",
        }}>
          {QUESTION.sub}
        </p>

        <div style={{ display: "flex", gap: 14, justifyContent: "center", flexWrap: "wrap" }}>
          <button
            onClick={handleYes}
            style={{
              background: "linear-gradient(135deg, #00c864, #00ff88)",
              border: "none",
              borderRadius: 16,
              color: "#050805",
              fontWeight: 900,
              fontSize: "1.05rem",
              padding: "1rem 3rem",
              cursor: "pointer",
              letterSpacing: "0.05em",
              boxShadow: "0 0 40px rgba(0,255,136,0.3), 0 4px 20px rgba(0,0,0,0.3)",
              transition: "transform 0.15s, box-shadow 0.15s",
              animation: "ctaPulse 2.5s ease-in-out infinite",
            }}
            onMouseEnter={e => {
              e.currentTarget.style.transform = "scale(1.06)"
              e.currentTarget.style.boxShadow = "0 0 60px rgba(0,255,136,0.5), 0 4px 24px rgba(0,0,0,0.4)"
              e.currentTarget.style.animation = "none"
            }}
            onMouseLeave={e => {
              e.currentTarget.style.transform = "scale(1)"
              e.currentTarget.style.boxShadow = "0 0 40px rgba(0,255,136,0.3), 0 4px 20px rgba(0,0,0,0.3)"
              e.currentTarget.style.animation = "ctaPulse 2.5s ease-in-out infinite"
            }}
          >
            Yes, I'm in
          </button>

          <button
            onClick={handleNo}
            style={{
              background: "rgba(255,255,255,0.04)",
              border: "1px solid rgba(255,255,255,0.1)",
              borderRadius: 16,
              color: "rgba(255,255,255,0.4)",
              fontWeight: 600,
              fontSize: "1.05rem",
              padding: "1rem 2.2rem",
              cursor: "pointer",
              letterSpacing: "0.03em",
              transition: "all 0.2s",
            }}
            onMouseEnter={e => {
              e.currentTarget.style.background = "rgba(255,255,255,0.07)"
              e.currentTarget.style.color = "rgba(255,255,255,0.6)"
            }}
            onMouseLeave={e => {
              e.currentTarget.style.background = "rgba(255,255,255,0.04)"
              e.currentTarget.style.color = "rgba(255,255,255,0.4)"
            }}
          >
            Not really
          </button>
        </div>
      </div>

      <style>{`
        @keyframes slideIn {
          from { opacity: 0; transform: translateY(32px) scale(0.97); }
          to { opacity: 1; transform: translateY(0) scale(1); }
        }
        @keyframes slideOut {
          from { opacity: 1; transform: translateY(0) scale(1); }
          to { opacity: 0; transform: translateY(-24px) scale(0.96); }
        }
        @keyframes ctaPulse {
          0%, 100% { box-shadow: 0 0 40px rgba(0,255,136,0.3), 0 4px 20px rgba(0,0,0,0.3); }
          50% { box-shadow: 0 0 70px rgba(0,255,136,0.55), 0 4px 30px rgba(0,0,0,0.4); }
        }
        @keyframes pulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.5; transform: scale(0.7); }
        }
      `}</style>
    </div>
  )
}
