import { useEffect, useState } from "react"

interface LoadingScreenProps {
  onComplete: () => void
}

export default function LoadingScreen({ onComplete }: LoadingScreenProps) {
  const [progress, setProgress] = useState(0)
  const [phase, setPhase] = useState<"loading" | "done">("loading")
  const [visible, setVisible] = useState(true)

  useEffect(() => {
    const totalMs = 2400
    const steps = 60
    const interval = totalMs / steps
    let current = 0

    const timer = setInterval(() => {
      current += 1
      const eased = Math.min(100, Math.round((1 - Math.pow(1 - current / steps, 2.5)) * 100))
      setProgress(eased)
      if (current >= steps) {
        clearInterval(timer)
        setPhase("done")
        setTimeout(() => {
          setVisible(false)
          setTimeout(onComplete, 400)
        }, 300)
      }
    }, interval)

    return () => clearInterval(timer)
  }, [onComplete])

  if (!visible) return null

  return (
    <div
      className="loading-screen"
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 9999,
        background: "#040c04",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        fontFamily: "Inter, sans-serif",
        transition: "opacity 0.4s ease",
        opacity: phase === "done" ? 0 : 1,
      }}
    >
      {/* Ambient glow */}
      <div style={{
        position: "absolute",
        width: 500,
        height: 500,
        borderRadius: "50%",
        background: "radial-gradient(circle, rgba(0,255,136,0.08) 0%, transparent 70%)",
        pointerEvents: "none",
      }} />

      {/* Animated candlestick bars */}
      <div style={{ display: "flex", alignItems: "flex-end", gap: 6, marginBottom: 40, height: 60 }}>
        {[40, 55, 35, 50, 60, 45, 52, 38, 58, 48].map((h, i) => (
          <div
            key={i}
            style={{
              width: 8,
              height: h,
              borderRadius: 3,
              background: i % 3 === 0
                ? "rgba(0,120,60,0.5)"
                : "linear-gradient(180deg, rgba(0,255,136,0.7) 0%, rgba(0,200,100,0.4) 100%)",
              animation: `candlePulse 1.4s ease-in-out ${i * 0.1}s infinite alternate`,
              opacity: 0.7,
            }}
          />
        ))}
      </div>

      {/* Logo */}
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 8 }}>
        <div style={{
          width: 36,
          height: 36,
          borderRadius: "50%",
          border: "2px solid rgba(0,255,136,0.6)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          background: "rgba(0,255,136,0.07)",
        }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
            <polyline points="22 7 13.5 15.5 8.5 10.5 2 17" stroke="#00ff88" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
            <polyline points="16 7 22 7 22 13" stroke="#00ff88" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
        <span style={{
          fontSize: "1.6rem",
          fontWeight: 800,
          letterSpacing: "0.12em",
          color: "#fff",
        }}>
          MIFTORA <span style={{ color: "#00ff88" }}>EA</span>
        </span>
      </div>

      <p style={{ color: "rgba(255,255,255,0.35)", fontSize: "0.78rem", letterSpacing: "0.2em", marginBottom: 48, textTransform: "uppercase" }}>
        Halal EA Hosting
      </p>

      {/* Progress bar */}
      <div style={{ width: 220, position: "relative" }}>
        <div style={{
          width: "100%",
          height: 3,
          borderRadius: 99,
          background: "rgba(255,255,255,0.07)",
          overflow: "hidden",
        }}>
          <div style={{
            height: "100%",
            borderRadius: 99,
            background: "linear-gradient(90deg, #00c864, #00ff88)",
            width: `${progress}%`,
            transition: "width 0.05s linear",
            boxShadow: "0 0 12px rgba(0,255,136,0.5)",
          }} />
        </div>
        <div style={{
          marginTop: 12,
          textAlign: "center",
          fontSize: "0.72rem",
          color: "rgba(255,255,255,0.3)",
          letterSpacing: "0.15em",
        }}>
          {progress < 100 ? "INITIALIZING..." : "READY"}
        </div>
      </div>

      <style>{`
        @keyframes candlePulse {
          from { transform: scaleY(0.6); opacity: 0.5; }
          to { transform: scaleY(1); opacity: 1; }
        }
      `}</style>
    </div>
  )
}
