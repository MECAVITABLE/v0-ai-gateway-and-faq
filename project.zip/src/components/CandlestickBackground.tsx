import { useEffect, useRef } from "react"

interface Candle {
  open: number
  close: number
  high: number
  low: number
}

const CANDLE_W = 14
const CANDLE_GAP = 6
const STEP = CANDLE_W + CANDLE_GAP
const PIXELS_PER_SEC = 21
const MA_PERIOD = 12
const INITIAL_OFFSET_PX = 2200

export default function CandlestickBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    let animId: number
    let startTime: number | null = null
    let price = 1.2500
    const candles: Candle[] = []
    let dpr = window.devicePixelRatio || 1

    function makeCandle(): Candle {
      const move = (Math.random() - 0.46) * 0.003
      const open = price
      const close = price + move
      const wick1 = Math.random() * 0.0015
      const wick2 = Math.random() * 0.0015
      const high = Math.max(open, close) + wick1
      const low = Math.min(open, close) - wick2
      price = close
      return { open, close, high, low }
    }

    function ensureCandles(needed: number) {
      while (candles.length < needed) candles.push(makeCandle())
    }

    function getMA(index: number): number | null {
      if (index < MA_PERIOD - 1) return null
      let sum = 0
      for (let i = index - MA_PERIOD + 1; i <= index; i++) {
        sum += (candles[i].open + candles[i].close) / 2
      }
      return sum / MA_PERIOD
    }

    const resize = () => {
      dpr = window.devicePixelRatio || 1
      canvas.width = canvas.offsetWidth * dpr
      canvas.height = canvas.offsetHeight * dpr
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
    }

    function draw(timestamp: number) {
      if (!canvas || !ctx) return
      if (startTime === null) startTime = timestamp
      const elapsed = (timestamp - startTime) / 1000
      const totalPixels = elapsed * PIXELS_PER_SEC + INITIAL_OFFSET_PX

      const W = canvas.offsetWidth
      const H = canvas.offsetHeight

      const rightmostIndex = Math.floor(totalPixels / STEP)
      const frac = totalPixels % STEP

      const visibleCount = Math.ceil(W / STEP) + 4
      ensureCandles(rightmostIndex + visibleCount + MA_PERIOD + 2)

      ctx.clearRect(0, 0, W, H)

      const firstVisible = Math.max(0, rightmostIndex - visibleCount)
      const visibleCandles = candles.slice(firstVisible, rightmostIndex + 2)
      const prices = visibleCandles.flatMap(c => [c.high, c.low])
      if (prices.length === 0) {
        animId = requestAnimationFrame(draw)
        return
      }
      const minP = Math.min(...prices)
      const maxP = Math.max(...prices)
      const range = maxP - minP || 0.005
      const padV = H * 0.15
      const toY = (p: number) => padV + (1 - (p - minP) / range) * (H - padV * 2)

      const gridLines = 6
      ctx.setLineDash([4, 8])
      for (let i = 0; i <= gridLines; i++) {
        const y = padV + (i / gridLines) * (H - padV * 2)
        ctx.beginPath()
        ctx.strokeStyle = "rgba(0,255,136,0.04)"
        ctx.lineWidth = 0.5
        ctx.moveTo(0, y)
        ctx.lineTo(W, y)
        ctx.stroke()
      }
      const vLines = Math.ceil(W / 120)
      for (let i = 0; i <= vLines; i++) {
        const x = (i / vLines) * W
        ctx.beginPath()
        ctx.strokeStyle = "rgba(0,255,136,0.025)"
        ctx.lineWidth = 0.5
        ctx.moveTo(x, padV)
        ctx.lineTo(x, H - padV)
        ctx.stroke()
      }
      ctx.setLineDash([])

      for (let i = firstVisible; i <= rightmostIndex + 1; i++) {
        if (i >= candles.length) break
        const c = candles[i]
        const kFromRight = rightmostIndex - i
        const x = W - frac - kFromRight * STEP - STEP

        if (x > W + STEP || x < -STEP * 2) continue

        const bull = c.close >= c.open
        const bodyTop = toY(Math.max(c.open, c.close))
        const bodyBot = toY(Math.min(c.open, c.close))
        const bodyH = Math.max(bodyBot - bodyTop, 2)
        const highY = toY(c.high)
        const lowY = toY(c.low)
        const cx = x + CANDLE_W / 2

        const distFromRight = kFromRight / visibleCount
        const fadeAlpha = Math.min(1, 0.3 + (1 - distFromRight) * 0.7)

        if (bull) {
          const glow = ctx.createRadialGradient(cx, (bodyTop + bodyBot) / 2, 0, cx, (bodyTop + bodyBot) / 2, CANDLE_W * 3)
          glow.addColorStop(0, `rgba(0,255,136,${0.06 * fadeAlpha})`)
          glow.addColorStop(1, "rgba(0,255,136,0)")
          ctx.fillStyle = glow
          ctx.fillRect(x - CANDLE_W * 2, bodyTop - 20, CANDLE_W * 5, bodyH + 40)
        }

        ctx.beginPath()
        ctx.strokeStyle = bull
          ? `rgba(0,255,136,${0.25 * fadeAlpha})`
          : `rgba(0,180,90,${0.15 * fadeAlpha})`
        ctx.lineWidth = 1.2
        ctx.moveTo(cx, highY)
        ctx.lineTo(cx, bodyTop)
        ctx.stroke()
        ctx.beginPath()
        ctx.moveTo(cx, bodyBot)
        ctx.lineTo(cx, lowY)
        ctx.stroke()

        const r = 1.5
        if (bull) {
          const g = ctx.createLinearGradient(x, bodyTop, x, bodyBot)
          g.addColorStop(0, `rgba(0,255,136,${0.40 * fadeAlpha})`)
          g.addColorStop(1, `rgba(0,200,100,${0.25 * fadeAlpha})`)
          ctx.fillStyle = g
        } else {
          const g = ctx.createLinearGradient(x, bodyTop, x, bodyBot)
          g.addColorStop(0, `rgba(0,160,80,${0.22 * fadeAlpha})`)
          g.addColorStop(1, `rgba(0,120,60,${0.12 * fadeAlpha})`)
          ctx.fillStyle = g
        }
        ctx.beginPath()
        ctx.moveTo(x + r, bodyTop)
        ctx.lineTo(x + CANDLE_W - r, bodyTop)
        ctx.arcTo(x + CANDLE_W, bodyTop, x + CANDLE_W, bodyTop + r, r)
        ctx.lineTo(x + CANDLE_W, bodyBot - r)
        ctx.arcTo(x + CANDLE_W, bodyBot, x + CANDLE_W - r, bodyBot, r)
        ctx.lineTo(x + r, bodyBot)
        ctx.arcTo(x, bodyBot, x, bodyBot - r, r)
        ctx.lineTo(x, bodyTop + r)
        ctx.arcTo(x, bodyTop, x + r, bodyTop, r)
        ctx.closePath()
        ctx.fill()
        ctx.strokeStyle = bull
          ? `rgba(0,255,136,${0.5 * fadeAlpha})`
          : `rgba(0,180,90,${0.25 * fadeAlpha})`
        ctx.lineWidth = 0.6
        ctx.stroke()
      }

      ctx.beginPath()
      ctx.strokeStyle = "rgba(0,255,200,0.18)"
      ctx.lineWidth = 1.5
      let maStarted = false
      for (let i = firstVisible; i <= rightmostIndex + 1; i++) {
        if (i >= candles.length) break
        const ma = getMA(i)
        if (ma === null) continue
        const kFromRight = rightmostIndex - i
        const x = W - frac - kFromRight * STEP - STEP + CANDLE_W / 2
        if (x < -STEP * 2 || x > W + STEP) continue
        const y = toY(ma)
        if (!maStarted) { ctx.moveTo(x, y); maStarted = true }
        else ctx.lineTo(x, y)
      }
      ctx.stroke()

      ctx.beginPath()
      ctx.strokeStyle = "rgba(0,255,200,0.05)"
      ctx.lineWidth = 5
      maStarted = false
      for (let i = firstVisible; i <= rightmostIndex + 1; i++) {
        if (i >= candles.length) break
        const ma = getMA(i)
        if (ma === null) continue
        const kFromRight = rightmostIndex - i
        const x = W - frac - kFromRight * STEP - STEP + CANDLE_W / 2
        if (x < -STEP * 2 || x > W + STEP) continue
        const y = toY(ma)
        if (!maStarted) { ctx.moveTo(x, y); maStarted = true }
        else ctx.lineTo(x, y)
      }
      ctx.stroke()

      const fadeLeft = ctx.createLinearGradient(0, 0, 200, 0)
      fadeLeft.addColorStop(0, "rgba(4,12,4,0.98)")
      fadeLeft.addColorStop(1, "rgba(4,12,4,0)")
      ctx.fillStyle = fadeLeft
      ctx.fillRect(0, 0, 200, H)

      const fadeRight = ctx.createLinearGradient(W - 160, 0, W, 0)
      fadeRight.addColorStop(0, "rgba(4,12,4,0)")
      fadeRight.addColorStop(1, "rgba(4,12,4,0.9)")
      ctx.fillStyle = fadeRight
      ctx.fillRect(W - 160, 0, 160, H)

      const fadeTop = ctx.createLinearGradient(0, 0, 0, H * 0.4)
      fadeTop.addColorStop(0, "rgba(4,12,4,0.95)")
      fadeTop.addColorStop(1, "rgba(4,12,4,0)")
      ctx.fillStyle = fadeTop
      ctx.fillRect(0, 0, W, H * 0.4)

      const fadeBot = ctx.createLinearGradient(0, H * 0.65, 0, H)
      fadeBot.addColorStop(0, "rgba(4,12,4,0)")
      fadeBot.addColorStop(1, "rgba(4,12,4,0.92)")
      ctx.fillStyle = fadeBot
      ctx.fillRect(0, H * 0.65, W, H * 0.35)

      animId = requestAnimationFrame(draw)
    }

    resize()
    window.addEventListener("resize", resize)
    const initialCandles = Math.ceil(INITIAL_OFFSET_PX / STEP) + 80
    ensureCandles(initialCandles)
    animId = requestAnimationFrame(draw)

    return () => {
      cancelAnimationFrame(animId)
      window.removeEventListener("resize", resize)
    }
  }, [])

  return (
    <canvas
      ref={canvasRef}
      className="candlestick-canvas"
      style={{
        position: "absolute",
        inset: 0,
        width: "100%",
        height: "100%",
        pointerEvents: "none",
        zIndex: 1,
      }}
    />
  )
}
