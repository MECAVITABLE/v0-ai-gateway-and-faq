import { useState, useEffect, useRef } from "react"
import { useLocation } from "wouter"
import { sendChat, FOUNDERS_BLURB, PRODUCT_BLURB } from "@/lib/chat"

const DOCTOR_SYSTEM = `You are Dr. Nova, the AI advisor for MIFTORA EA — a halal EA hosting service for the stock market.

You were built by the founders of MIFTORA EA to help users understand halal automated stock trading and EA hosting, and take action with confidence.

Your tone:
- Motivating and energetic, but professional — not over-the-top or cringe
- Use 1-2 emojis per response max, only where they add value
- Keep responses concise: 2-4 sentences max
- Focus on delivering real value and clear information
- Do NOT overuse the user's name. Only use it if they have introduced themselves
- Do NOT pretend to have a close personal relationship with the user

${FOUNDERS_BLURB}

${PRODUCT_BLURB}

Always end with a gentle nudge toward hosting an EA with MIFTORA EA.`

interface Msg {
  role: "user" | "assistant"
  content: string
}

const INITIAL_MESSAGES: Msg[] = [
  {
    role: "assistant",
    content: "Hey! I'm Dr. Nova 🚀 — the MIFTORA EA AI advisor, built by the founders to help you get started with halal EA hosting for stocks. Got questions? Ask me anything about how it works, the halal approach, the risks, or how to begin."
  }
]

const MOTIVATIONAL_PROMPTS = [
  "Am I ready to start investing? 💭",
  "What does EA hosting mean? 🤔",
  "Is this really halal? 🌙",
  "How does my EA run 24/7? ⚙️",
  "What makes MIFTORA EA special? ⭐",
  "I'm scared of losing money 😰",
]

function StarField() {
  return (
    <div className="doctor-stars">
      {Array.from({ length: 60 }).map((_, i) => (
        <div
          key={i}
          className="doctor-star"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            animationDelay: `${Math.random() * 4}s`,
            animationDuration: `${2 + Math.random() * 3}s`,
            width: `${1 + Math.random() * 2}px`,
            height: `${1 + Math.random() * 2}px`,
          }}
        />
      ))}
    </div>
  )
}

function AIPulse() {
  return (
    <div className="doctor-ai-pulse">
      <div className="pulse-ring pulse-ring-1" />
      <div className="pulse-ring pulse-ring-2" />
      <div className="pulse-ring pulse-ring-3" />
      <div className="pulse-core">
        <span className="material-icons-outlined" style={{ fontSize: 36, color: "#00ff88" }}>smart_toy</span>
      </div>
    </div>
  )
}

export default function ConsultDoctorAI() {
  const [, navigate] = useLocation()
  const [msgs, setMsgs] = useState<Msg[]>(INITIAL_MESSAGES)
  const [input, setInput] = useState("")
  const [loading, setLoading] = useState(false)
  const [headerVisible, setHeaderVisible] = useState(false)
  const [chatVisible, setChatVisible] = useState(false)
  const bottomRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    window.scrollTo(0, 0)
    const t1 = setTimeout(() => setHeaderVisible(true), 200)
    const t2 = setTimeout(() => setChatVisible(true), 700)
    return () => { clearTimeout(t1); clearTimeout(t2) }
  }, [])

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [msgs])

  const send = async (text?: string) => {
    const content = (text ?? input).trim()
    if (!content || loading) return
    const userMsg: Msg = { role: "user", content }
    setMsgs(p => [...p, userMsg])
    setInput("")
    setLoading(true)
    try {
      const reply = (await sendChat({
        system: DOCTOR_SYSTEM,
        messages: [...msgs, userMsg],
        maxTokens: 300,
        temperature: 0.85,
      })) || "🚀💊 Dr. Nova's transmitter is buffering! Please try again, Champion! ✨"
      setMsgs(p => [...p, { role: "assistant", content: reply }])
    } catch {
      setMsgs(p => [...p, {
        role: "assistant",
        content: "🚀⚡ Temporary signal disruption from the Space Station! Dr. Nova will be right back — please try again! 💫"
      }])
    } finally {
      setLoading(false)
    }
  }

  return (
    <>
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet" />

      <div className="doctor-root">
        <StarField />

        <div className="doctor-nebula doctor-nebula-1" />
        <div className="doctor-nebula doctor-nebula-2" />
        <div className="doctor-nebula doctor-nebula-3" />

        {/* Nav */}
        <nav className="hiw-page-nav navbar-visible">
          <div className="nav-content">
            <button className="hiw-back-btn" onClick={() => navigate("/")} type="button">
              <span className="material-icons-outlined">arrow_back</span>
              Back
            </button>
            <div className="logo">
              <span className="material-icons-outlined logo-icon">eco</span>
              <span className="logo-text">MIFTORA EA</span>
            </div>
            <a
              href="https://instagram.com/mhdkpy"
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn-primary hiw-nav-cta"
              style={{ padding: "0.55rem 1.2rem", fontSize: "0.88rem" }}
            >
              <span className="material-icons-outlined">flash_on</span>
              Get Started
              <span className="btn-glow" />
            </a>
          </div>
        </nav>

        {/* Header Section */}
        <div className={`doctor-header ${headerVisible ? "doctor-visible" : ""}`}>
          <div className="doctor-badge">
            <span className="material-icons-outlined">local_hospital</span>
            AI Consultation · Free · Instant
          </div>

          <AIPulse />

          <h1 className="doctor-title">
            Consult <span className="doctor-title-highlight">Doctor AI</span>
          </h1>
          <p className="doctor-subtitle">
            🩺 Meet Dr. Nova — your personal Financial Wellness Doctor powered by AI 🚀<br />
            Get motivated, get answers, get rich 💰✨
          </p>

          {/* Feature Pills */}
          <div className="doctor-pills">
            {[
              { icon: "psychology", label: "AI Powered 🤖" },
              { icon: "rocket_launch", label: "Space Grade 🚀" },
              { icon: "favorite", label: "Free Forever 💚" },
              { icon: "verified", label: "MIFTORA Expert ⭐" },
            ].map((pill) => (
              <div className="doctor-pill" key={pill.label}>
                <span className="material-icons-outlined" style={{ fontSize: 14 }}>{pill.icon}</span>
                {pill.label}
              </div>
            ))}
          </div>
        </div>

        {/* Chat Section */}
        <div className={`doctor-chat-wrapper ${chatVisible ? "doctor-chat-visible" : ""}`}>
          {/* Quick Prompts */}
          <div className="doctor-prompts">
            <p className="doctor-prompts-label">
              <span className="material-icons-outlined" style={{ fontSize: 14 }}>tips_and_updates</span>
              Quick questions for Dr. Nova:
            </p>
            <div className="doctor-prompts-grid">
              {MOTIVATIONAL_PROMPTS.map((prompt) => (
                <button
                  key={prompt}
                  className="doctor-prompt-btn"
                  onClick={() => send(prompt)}
                  disabled={loading}
                  type="button"
                >
                  {prompt}
                </button>
              ))}
            </div>
          </div>

          {/* Chat Box */}
          <div className="doctor-chat-box">
            <div className="doctor-chat-header">
              <div className="doctor-live-dot" />
              <span className="material-icons-outlined" style={{ fontSize: 16, color: "#00ff88" }}>smart_toy</span>
              <span>Dr. Nova — MIFTORA EA AI Doctor</span>
              <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 6, fontSize: "0.75rem", color: "rgba(0,255,136,0.6)" }}>
                <span className="material-icons-outlined" style={{ fontSize: 14 }}>satellite</span>
                Live from Space Station 🛸
              </div>
            </div>

            <div className="doctor-msgs">
              {msgs.map((m, i) => (
                <div key={i} className={`doctor-msg-row doctor-msg-${m.role}`}>
                  {m.role === "assistant" && (
                    <div className="doctor-avatar">
                      <span className="material-icons-outlined" style={{ fontSize: 18 }}>smart_toy</span>
                    </div>
                  )}
                  <div className="doctor-bubble">{m.content}</div>
                  {m.role === "user" && (
                    <div className="doctor-avatar doctor-avatar-user">
                      <span className="material-icons-outlined" style={{ fontSize: 18 }}>person</span>
                    </div>
                  )}
                </div>
              ))}

              {loading && (
                <div className="doctor-msg-row doctor-msg-assistant">
                  <div className="doctor-avatar">
                    <span className="material-icons-outlined" style={{ fontSize: 18 }}>smart_toy</span>
                  </div>
                  <div className="doctor-bubble doctor-typing">
                    <span />
                    <span />
                    <span />
                  </div>
                </div>
              )}
              <div ref={bottomRef} />
            </div>

            <div className="doctor-input-bar">
              <input
                className="doctor-input"
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={e => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault()
                    send()
                  }
                }}
                placeholder="Ask Dr. Nova anything... 🩺✨"
                disabled={loading}
                autoComplete="off"
              />
              <button
                className="doctor-send-btn"
                onClick={() => send()}
                disabled={loading || !input.trim()}
                type="button"
              >
                <span className="material-icons-outlined">send</span>
              </button>
            </div>
          </div>

          {/* Bottom CTA */}
          <div className="doctor-cta-bar">
            <div className="doctor-cta-text">
              <span className="material-icons-outlined" style={{ color: "#00ff88", fontSize: 20 }}>rocket_launch</span>
              <div>
                <div style={{ fontWeight: 700, fontSize: "0.95rem" }}>Ready to host your EA the halal way? 🚀</div>
                <div style={{ fontSize: "0.8rem", color: "rgba(255,255,255,0.6)" }}>Join MIFTORA EA — halal stock trading, hosted 24/7 ✨</div>
              </div>
            </div>
            <a
              href="https://instagram.com/mhdkpy"
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn-primary"
              style={{ whiteSpace: "nowrap" }}
            >
              <span className="material-icons-outlined">flash_on</span>
              Get Started
              <span className="btn-glow" />
            </a>
          </div>
        </div>
      </div>
    </>
  )
}
