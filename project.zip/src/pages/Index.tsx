import { useEffect, useRef, useState } from "react"
import HelpFAQ from "@/components/HelpFAQ"
import PlantGrowth from "@/components/PlantGrowth"
import CandlestickBackground from "@/components/CandlestickBackground"
import TradeFeed from "@/components/TradeFeed"
import { useLocation } from "wouter"

export default function MiftoraEA() {
  const [isLoaded, setIsLoaded] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const [showCreatorsFooter, setShowCreatorsFooter] = useState(false)
  const [creatorsPos, setCreatorsPos] = useState({ bottom: 0, left: 0 })
  const creatorsButtonRef = useRef<HTMLButtonElement>(null)
  const cursorRef = useRef<HTMLDivElement>(null)
  const trailContainerRef = useRef<HTMLDivElement>(null)
  const [, navigate] = useLocation()

  const toggleCreators = () => {
    if (!showCreatorsFooter && creatorsButtonRef.current) {
      const rect = creatorsButtonRef.current.getBoundingClientRect()
      setCreatorsPos({
        bottom: window.innerHeight - rect.top + 10,
        left: rect.left + rect.width / 2,
      })
    }
    setShowCreatorsFooter(o => !o)
  }

  const closeMenu = () => setMenuOpen(false)

  useEffect(() => { setIsLoaded(true) }, [])

  /* Scroll indicator fade */
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60)
    window.addEventListener("scroll", onScroll, { passive: true })
    return () => window.removeEventListener("scroll", onScroll)
  }, [])

  /* Cursor + dollar trail */
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (cursorRef.current) {
        cursorRef.current.style.left = `${e.clientX}px`
        cursorRef.current.style.top = `${e.clientY}px`
      }
      if (trailContainerRef.current) {
        const dollar = document.createElement("span")
        dollar.className = "dollar-trail"
        dollar.textContent = "$"
        dollar.style.left = `${e.clientX}px`
        dollar.style.top = `${e.clientY}px`
        trailContainerRef.current.appendChild(dollar)
        setTimeout(() => dollar.remove(), 1000)
      }
    }
    window.addEventListener("mousemove", handleMouseMove)
    return () => window.removeEventListener("mousemove", handleMouseMove)
  }, [])

  /* Particles */
  useEffect(() => {
    const createParticle = () => {
      const particles = document.getElementById("particles")
      if (!particles) return
      const particle = document.createElement("div")
      particle.className = "particle"
      particle.style.left = `${Math.random() * 100}%`
      particle.style.animationDuration = `${Math.random() * 10 + 10}s`
      particle.style.opacity = `${Math.random() * 0.3 + 0.1}`
      particles.appendChild(particle)
      setTimeout(() => particle.remove(), 20000)
    }
    const interval = setInterval(createParticle, 500)
    return () => clearInterval(interval)
  }, [])

  /* Scroll Reveal */
  useEffect(() => {
    const els = document.querySelectorAll("[data-sr]")
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const el = entry.target as HTMLElement
            const delay = el.dataset.delay || "0"
            setTimeout(() => el.classList.add("sr-visible"), Number(delay))
            observer.unobserve(el)
          }
        })
      },
      { threshold: 0.12, rootMargin: "0px 0px -40px 0px" }
    )
    els.forEach((el) => observer.observe(el))
    return () => observer.disconnect()
  }, [isLoaded])

  return (
    <>
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet" />

      <div className="miftora-app">
        <div ref={cursorRef} className="custom-cursor" />
        <div ref={trailContainerRef} className="trail-container" />
        <div id="particles" className="particles-container" />

        <div className="ambient-glow ambient-glow-1" />
        <div className="ambient-glow ambient-glow-2" />
        <div className="ambient-glow ambient-glow-3" />
        <div className="ambient-glow ambient-glow-4" />
        <div className="floating-orb orb-1" />
        <div className="floating-orb orb-2" />
        <div className="floating-orb orb-3" />

        {/* Navigation */}
        <nav className={`navbar ${isLoaded ? "navbar-visible" : ""}`}>
          <div className="nav-content">
            <div className="logo">
              <span className="material-icons-outlined logo-icon">eco</span>
              <span className="logo-text">MIFTORA EA</span>
            </div>
            <div className="nav-links">
              <a href="#features" className="nav-link"><span className="material-icons-outlined">auto_awesome</span>Features</a>
              <a href="#transparency" className="nav-link"><span className="material-icons-outlined">verified</span>Transparency</a>

              <a href="#connect" className="nav-link nav-link-cta"><span className="material-icons-outlined">link</span>Connect</a>
            </div>
            <button
              className="mobile-menu-btn"
              onClick={() => setMenuOpen(o => !o)}
              aria-label="Toggle menu"
              type="button"
            >
              <span className="material-icons-outlined">
                {menuOpen ? "close" : "menu"}
              </span>
            </button>
          </div>
        </nav>

        {/* Mobile Menu Overlay */}
        <div className={`mobile-menu-overlay ${menuOpen ? "mobile-menu-open" : ""}`} onClick={closeMenu}>
          <div className="mobile-menu-drawer" onClick={e => e.stopPropagation()}>
            <div className="mobile-menu-header">
              <div className="logo">
                <span className="material-icons-outlined logo-icon">eco</span>
                <span className="logo-text">MIFTORA EA</span>
              </div>
              <button className="mobile-menu-close" onClick={closeMenu} type="button">
                <span className="material-icons-outlined">close</span>
              </button>
            </div>
            <div className="mobile-menu-links">
              <a href="#features" className="mobile-menu-link" onClick={closeMenu}>
                <span className="material-icons-outlined">auto_awesome</span>Features
              </a>
              <a href="#transparency" className="mobile-menu-link" onClick={closeMenu}>
                <span className="material-icons-outlined">verified</span>Transparency
              </a>
              <a href="#connect" className="mobile-menu-link" onClick={closeMenu}>
                <span className="material-icons-outlined">link</span>Connect
              </a>
              <div className="mobile-menu-divider" />
              <button className="mobile-menu-link mobile-hiw-link" onClick={() => { closeMenu(); navigate("/how-it-works") }} type="button">
                <span className="material-icons-outlined">play_circle</span>How It Works
              </button>
            </div>
            <div className="mobile-menu-footer">
              <a href="https://instagram.com/mhdkpy" target="_blank" rel="noopener noreferrer" className="btn btn-primary btn-full">
                <span className="material-icons-outlined">flash_on</span>Get Started
                <span className="btn-glow" />
              </a>
            </div>
          </div>
        </div>

        {/* Hero */}
        <section className="hero hero-split" style={{ position: "relative" }}>
          <CandlestickBackground />
          <div className="hero-inner">
            <div className={`hero-content ${isLoaded ? "hero-visible" : ""}`}>
              <div className="hero-text">
                <div className="hero-badge">
                  <span className="material-icons-outlined">trending_up</span>
                  Halal EA Hosting
                </div>
                <h1 className="hero-title">
                  Halal Stock Trading
                  <span className="title-highlight"> Automated</span>
                </h1>
                <p className="hero-subtitle">
                  MIFTORA EA — Secure EA Hosting for Shariah-Compliant Stock Trading
                </p>
              </div>
              <div className="hero-buttons">
                <a href="https://instagram.com/mhdkpy" target="_blank" rel="noopener noreferrer" className="btn btn-primary">
                  <span className="material-icons-outlined">dns</span>
                  Host Your EA
                  <span className="btn-glow" />
                </a>
                <a href="#transparency" className="btn btn-secondary">
                  <span className="material-icons-outlined">verified</span>
                  Halal Guidelines
                </a>
                <button className="btn btn-hiw" onClick={() => navigate("/how-it-works")} type="button">
                  <span className="material-icons-outlined">play_circle</span>
                  How It Works
                </button>
                <a href="https://stratagem-diary.lovable.app" target="_blank" rel="noopener noreferrer" className="btn btn-secondary">
                  <span className="material-icons-outlined">trending_up</span>
                  Track Progress
                </a>
              </div>
            </div>
            <div className="hero-plant-wrapper desktop-only">
              <PlantGrowth />
            </div>
          </div>

          {/* Scroll Indicator — mouse only, no arrows, no text */}
          <div
            className={`scroll-indicator${scrolled ? " scroll-indicator-hidden" : ""}`}
            onClick={() => document.getElementById("social-proof")?.scrollIntoView({ behavior: "smooth" })}
          >
            <div className="scroll-mouse">
              <div className="scroll-wheel" />
            </div>
          </div>
        </section>

        {/* Live Trade Feed */}
        <TradeFeed />

        {/* Social Proof */}
        <section id="social-proof" className="social-proof">
          <div className="social-proof-inner">
            {[
              { icon: "dns",           value: "24/7",    label: "Server Uptime" },
              { icon: "verified",      value: "100%",    label: "Halal Screened Stocks" },
              { icon: "block",         value: "0%",      label: "Interest (Riba)" },
              { icon: "balance",       value: "1:1",     label: "No Leverage" },
              { icon: "security",      value: "Your",    label: "Own Broker Account" },
            ].map((stat, i) => (
              <div className="social-stat" key={i}>
                <span className="material-icons-outlined social-stat-icon">{stat.icon}</span>
                <div className="social-stat-value">{stat.value}</div>
                <div className="social-stat-label">{stat.label}</div>
              </div>
            ))}
          </div>
        </section>

        {/* Features */}
        <section id="features" className="features">
          <div className="section-header">
            <span className="section-badge sr-up" data-sr data-delay="0">
              <span className="material-icons-outlined">bolt</span>
              Core Features
            </span>
            <h2 className="section-title sr-blur" data-sr data-delay="100">Why Choose MIFTORA EA?</h2>
          </div>

          <div className="features-grid">
            {[
              { icon: "dns",           title: "Always-On Hosting",   desc: "Your EA runs on secure servers around the clock — no need to keep your PC on" },
              { icon: "verified_user", title: "Halal Stocks Only",   desc: "Only Shariah-screened stocks — no alcohol, gambling or interest-based companies" },
              { icon: "block",         title: "No Riba, No Leverage", desc: "Cash-based trading only. No margin, no borrowing, no interest or swap fees" },
              { icon: "visibility",    title: "Full Transparency",   desc: "Clear logs and reports of every trade your EA makes" },
              { icon: "shield",        title: "You Stay in Control", desc: "Your funds stay in your own broker account. We never hold your money" },
              { icon: "smart_toy",     title: "Fully Automated",     desc: "Hands-free execution during market hours, managed on our servers" },
            ].map((card, i) => (
              <div key={card.title} className="feature-card sr-up" data-sr data-delay={String(i * 80)}>
                <div className="feature-icon">
                  <span className="material-icons-outlined">{card.icon}</span>
                </div>
                <h3>{card.title}</h3>
                <p>{card.desc}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Transparency */}
        <section id="transparency" className="transparency">
          <div className="section-header">
            <span className="section-badge sr-up" data-sr data-delay="0">
              <span className="material-icons-outlined">lock_open</span>
              Halal &amp; Transparent
            </span>
            <h2 className="section-title sr-blur" data-sr data-delay="100">Host &amp; Verify</h2>
            <p className="section-subtitle sr-up" data-sr data-delay="180">
              We believe in complete transparency. Host your EA with us and see exactly what it trades, and why it stays halal.
            </p>
          </div>

          <div className="connect-cards">
            <div className="connect-card sr-left" data-sr data-delay="0">
              <div className="connect-card-header">
                <span className="material-icons-outlined">account_balance</span>
                <h3>Your Broker Account</h3>
              </div>
              <p>Use your own Shariah-compliant stock broker account. Your EA trades there, and your funds always stay with you.</p>
              <a href="https://instagram.com/mhdkpy" target="_blank" rel="noopener noreferrer" className="btn btn-primary btn-full">
                <span className="material-icons-outlined">link</span>
                Host Your EA
                <span className="btn-glow" />
              </a>
            </div>

            <div className="connect-card sr-right" data-sr data-delay="120">
              <div className="connect-card-header">
                <span className="material-icons-outlined">bar_chart</span>
                <h3>Halal Screening</h3>
              </div>
              <p>Cash trading only: no leverage, no interest, no short selling, and only Shariah-screened stocks.</p>
              <a href="#features" className="btn btn-secondary btn-full">
                <span className="material-icons-outlined">open_in_new</span>
                See Halal Rules
              </a>
            </div>
          </div>
        </section>

        {/* CTA */}
        <section id="connect" className="cta-section">
          <div className="cta-content sr-scale" data-sr data-delay="0">
            <div className="cta-glow" />
            <span className="material-icons-outlined cta-icon">rocket_launch</span>
            <h2>Ready to Host Your EA?</h2>
            <p>Join MIFTORA EA today and run your trading bot the halal way</p>
            <div className="cta-buttons">
              <a href="https://instagram.com/mhdkpy" target="_blank" rel="noopener noreferrer" className="btn btn-primary btn-large" style={{ animation: "ctaButtonPulse 2.2s ease-in-out infinite", position: "relative" }}>
                <span className="material-icons-outlined">flash_on</span>
                Get Started Now
                <span className="btn-glow" />
              </a>
              <style>{`
                @keyframes ctaButtonPulse {
                  0%, 100% { box-shadow: 0 0 20px rgba(0,255,136,0.25), 0 4px 16px rgba(0,0,0,0.3); transform: scale(1); }
                  50% { box-shadow: 0 0 55px rgba(0,255,136,0.55), 0 6px 28px rgba(0,0,0,0.4); transform: scale(1.03); }
                }
              `}</style>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="footer">
          <div className="footer-content sr-up" data-sr data-delay="0">
            <div className="footer-brand">
              <span className="material-icons-outlined">eco</span>
              <span>MIFTORA EA</span>
            </div>
            <div className="footer-links">
              <a href="#features">
                <span className="material-icons-outlined">verified</span>Halal Rules
              </a>
              <a href="https://instagram.com/mhdkpy" target="_blank" rel="noopener noreferrer">
                <span className="material-icons-outlined">chat</span>Contact
              </a>
              <a href="https://stratagem-diary.lovable.app" target="_blank" rel="noopener noreferrer">
                <span className="material-icons-outlined">trending_up</span>Track Progress
              </a>
              <div style={{ position: "relative" }}>
                <button
                  ref={creatorsButtonRef}
                  onClick={toggleCreators}
                  style={{
                    display: "flex", alignItems: "center", gap: "6px",
                    background: showCreatorsFooter ? "rgba(0,255,128,0.1)" : "rgba(255,255,255,0.05)",
                    border: showCreatorsFooter ? "1px solid rgba(0,255,128,0.35)" : "1px solid rgba(255,255,255,0.15)",
                    borderRadius: "999px", padding: "6px 14px",
                    color: showCreatorsFooter ? "#00ff80" : "rgba(255,255,255,0.75)",
                    fontSize: "0.75rem", fontWeight: 600, cursor: "pointer", letterSpacing: "0.03em",
                    transition: "all 0.25s ease",
                    animation: "creatorsGlow 3s ease-in-out infinite",
                  }}
                >
                  <span>✌️</span> Creators
                </button>
                {showCreatorsFooter && (
                  <div style={{
                    position: "fixed",
                    bottom: creatorsPos.bottom,
                    left: creatorsPos.left,
                    transform: "translateX(-50%)",
                    background: "rgba(8,18,12,0.98)", border: "1px solid rgba(0,255,128,0.18)",
                    borderRadius: "14px", padding: "10px", display: "flex", gap: "8px", flexDirection: "column",
                    minWidth: "210px", boxShadow: "0 8px 32px rgba(0,0,0,0.6)", zIndex: 9999,
                    animation: "popupSlideUp 0.3s cubic-bezier(0.22,1,0.36,1)",
                  }}>
                    <a href="https://instagram.com/mhdkpy" target="_blank" rel="noopener noreferrer"
                      style={{
                        display: "flex", alignItems: "center", gap: "8px",
                        background: "rgba(120,160,255,0.07)", border: "1px solid rgba(120,160,255,0.2)",
                        borderRadius: "9px", padding: "7px 10px", color: "#90b4ff",
                        textDecoration: "none", fontSize: "0.76rem",
                        animation: "popupItemIn 0.35s cubic-bezier(0.22,1,0.36,1) 0.05s both",
                      }}>
                      <span style={{ fontWeight: 800, background: "rgba(120,160,255,0.2)", borderRadius: "50%", width: "28px", height: "28px", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.67rem", flexShrink: 0 }}>K</span>
                      <span>
                        <span style={{ display: "block", fontWeight: 700, lineHeight: 1.3 }}>Muhammed KP</span>
                        <span style={{ display: "block", opacity: 0.6, fontSize: "0.67rem" }}>@mhdkpy on Instagram</span>
                      </span>
                    </a>
                    <a href="https://instagram.com/m.najey" target="_blank" rel="noopener noreferrer"
                      style={{
                        display: "flex", alignItems: "center", gap: "8px",
                        background: "rgba(0,255,128,0.07)", border: "1px solid rgba(0,255,128,0.2)",
                        borderRadius: "9px", padding: "7px 10px", color: "#00ff80",
                        textDecoration: "none", fontSize: "0.76rem",
                        animation: "popupItemIn 0.35s cubic-bezier(0.22,1,0.36,1) 0.12s both",
                      }}>
                      <span style={{ fontWeight: 800, background: "rgba(0,255,128,0.2)", borderRadius: "50%", width: "28px", height: "28px", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.72rem", flexShrink: 0 }}>MN</span>
                      <span>
                        <span style={{ display: "block", fontWeight: 700, lineHeight: 1.3 }}>Muhammed Najih</span>
                        <span style={{ display: "block", opacity: 0.6, fontSize: "0.67rem" }}>@m.najey on Instagram</span>
                      </span>
                    </a>
                    <a href="https://instagram.com/m_asluu_t.x" target="_blank" rel="noopener noreferrer"
                      style={{
                        display: "flex", alignItems: "center", gap: "8px",
                        background: "rgba(255,170,90,0.07)", border: "1px solid rgba(255,170,90,0.22)",
                        borderRadius: "9px", padding: "7px 10px", color: "#ffb870",
                        textDecoration: "none", fontSize: "0.76rem",
                        animation: "popupItemIn 0.35s cubic-bezier(0.22,1,0.36,1) 0.19s both",
                      }}>
                      <span style={{ fontWeight: 800, background: "rgba(255,170,90,0.2)", borderRadius: "50%", width: "28px", height: "28px", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.72rem", flexShrink: 0 }}>A</span>
                      <span>
                        <span style={{ display: "block", fontWeight: 700, lineHeight: 1.3 }}>Aslam</span>
                        <span style={{ display: "block", opacity: 0.6, fontSize: "0.67rem" }}>@m_asluu_t.x on Instagram</span>
                      </span>
                    </a>
                  </div>
                )}
                <style>{`
                  @keyframes creatorsGlow {
                    0%, 100% { box-shadow: 0 0 0px rgba(0,255,128,0); }
                    50% { box-shadow: 0 0 10px rgba(0,255,128,0.25); }
                  }
                  @keyframes popupSlideUp {
                    from { opacity: 0; transform: translateX(-50%) translateY(10px); }
                    to { opacity: 1; transform: translateX(-50%) translateY(0); }
                  }
                  @keyframes popupItemIn {
                    from { opacity: 0; transform: translateY(8px); }
                    to { opacity: 1; transform: translateY(0); }
                  }
                `}</style>
              </div>
            </div>
            <p className="footer-copy">© 2024 MIFTORA EA. All rights reserved.</p>
          </div>
        </footer>

        <HelpFAQ />
      </div>
    </>
  )
}
