import { useState, useEffect, useLayoutEffect, useRef, useCallback } from "react"
import { useLocation } from "wouter"
import { sendChat, FOUNDERS_BLURB, PRODUCT_BLURB } from "@/lib/chat"

function CustomCursor() {
  const cursorRef = useRef<HTMLDivElement>(null)
  const trailRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const onMove = (e: MouseEvent) => {
      if (cursorRef.current) {
        cursorRef.current.style.left = `${e.clientX}px`
        cursorRef.current.style.top = `${e.clientY}px`
      }
      if (trailRef.current) {
        const dollar = document.createElement("span")
        dollar.className = "dollar-trail"
        dollar.textContent = "$"
        dollar.style.left = `${e.clientX}px`
        dollar.style.top = `${e.clientY}px`
        trailRef.current.appendChild(dollar)
        setTimeout(() => dollar.remove(), 1000)
      }
    }
    window.addEventListener("mousemove", onMove)
    return () => window.removeEventListener("mousemove", onMove)
  }, [])

  return (
    <>
      <div ref={cursorRef} className="custom-cursor" />
      <div ref={trailRef} className="trail-container" />
    </>
  )
}

const HOW_IT_WORKS_SYSTEM = `You are Dr. Rabbit, the AI advisor built by the founders of MIFTORA EA — a halal EA hosting service for the stock market.

Your job is to help users understand how MIFTORA EA works and guide them through getting started.

${FOUNDERS_BLURB}

${PRODUCT_BLURB}

Rules:
- Speak in simple, plain English. No jargon.
- Keep it short: 1-3 sentences max per reply.
- Be warm and helpful — not overly familiar or salesy.
- Do NOT overuse the user's name. Only use it if they have introduced themselves.
- Use 1 emoji per message at most, only when it adds clarity.
- End every reply with a gentle nudge toward hosting an EA with MIFTORA EA.`

const STEPS = [
  {
    number: "01", icon: "account_balance", color: "#00ff88",
    title: "Open a Halal Broker Account",
    desc: "Open a cash (non-margin) account with a Shariah-compliant stock broker. No interest, no leverage, no swap fees.",
    detail: "Your funds stay in your own account — we never hold your money.",
    link: null
  },
  {
    number: "02", icon: "account_balance_wallet", color: "#00ffaa",
    title: "Fund Your Account",
    desc: "Deposit an amount you are comfortable with using your broker's payment methods.",
    detail: "Only invest what you can afford to lose. Start small and scale up as your confidence grows.",
    link: null
  },
  {
    number: "03", icon: "dns", color: "#00ffcc",
    title: "Host Your EA With MIFTORA",
    desc: "Contact our team and we set up your EA on our secure, always-on servers, connected to your broker account.",
    detail: "Your EA runs 24/7 on our hosting, so you never need to keep your own PC running.",
    link: { label: "Contact the Team on Instagram", url: "https://instagram.com/mhdkpy" }
  },
  {
    number: "04", icon: "trending_up", color: "#00ff88",
    title: "Monitor Your EA",
    desc: "Your EA trades only Shariah-screened stocks during market hours. Review logs and reports of every trade.",
    detail: "Cash-only, no leverage, no riba. Profits stay in your own broker account, and you can stop anytime.",
    link: null
  }
]

interface Msg { role: "user" | "assistant"; content: string }

function DrRabbitChat({ onClose }: { onClose: () => void }) {
  const [msgs, setMsgs] = useState<Msg[]>([
    { role: "assistant", content: "Hey, I'm Dr. Rabbit 🐰 Still have questions about how it works? Ask me anything — I'll walk you through it!" }
  ])
  const [input, setInput] = useState("")
  const [loading, setLoading] = useState(false)
  const bottomRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [msgs])

  const send = useCallback(async (text?: string) => {
    const content = (text ?? input).trim()
    if (!content || loading) return
    const userMsg: Msg = { role: "user", content }
    setMsgs(p => [...p, userMsg])
    setInput("")
    setLoading(true)
    try {
      const reply = (await sendChat({
        system: HOW_IT_WORKS_SYSTEM,
        messages: [...msgs, userMsg],
        maxTokens: 180,
        temperature: 0.8,
      })) || "Something went wrong on my end. Please try again."
      setMsgs(p => [...p, { role: "assistant", content: reply }])
    } catch {
      setMsgs(p => [...p, { role: "assistant", content: "Connection issue. Please try again in a moment." }])
    } finally {
      setLoading(false)
    }
  }, [input, loading, msgs])

  return (
    <div style={{
      position: "fixed",
      bottom: 20,
      right: 20,
      width: 320,
      maxWidth: "calc(100vw - 40px)",
      height: 340,
      display: "flex",
      flexDirection: "column",
      overflow: "hidden",
      background: "rgba(8, 12, 8, 0.95)",
      border: "1px solid rgba(0,255,136,0.18)",
      borderRadius: 16,
      boxShadow: "0 12px 40px rgba(0,0,0,0.6), 0 0 30px rgba(0,255,136,0.06)",
      backdropFilter: "blur(20px)",
      zIndex: 10000,
      fontFamily: "'Courier New', 'SF Mono', 'Fira Code', monospace",
      animation: "chatWindowIn 0.3s ease",
    }}>
      {/* Header */}
      <div style={{
        display: "flex", alignItems: "center", gap: 6,
        padding: "10px 14px",
        borderBottom: "1px solid rgba(0,255,136,0.12)",
        background: "rgba(0,255,136,0.04)",
        flexShrink: 0,
      }}>
        <div style={{
          width: 6, height: 6, borderRadius: "50%", background: "#00ff88",
          boxShadow: "0 0 6px rgba(0,255,136,0.8)",
          animation: "livePulse 2s ease-in-out infinite",
        }} />
        <span style={{ fontSize: "0.72rem", color: "rgba(255,255,255,0.5)", fontWeight: 600, flex: 1 }}>
          🐰 Dr. Rabbit — AI Advisor
        </span>
        <button
          onClick={onClose}
          style={{
            width: 22, height: 22, borderRadius: 6,
            background: "rgba(255,255,255,0.06)",
            border: "1px solid rgba(255,255,255,0.1)",
            color: "rgba(255,255,255,0.4)",
            fontSize: "0.7rem", cursor: "pointer",
            display: "flex", alignItems: "center", justifyContent: "center",
            transition: "all 0.2s",
          }}
          onMouseEnter={e => { e.currentTarget.style.background = "rgba(255,80,80,0.15)"; e.currentTarget.style.color = "#fff" }}
          onMouseLeave={e => { e.currentTarget.style.background = "rgba(255,255,255,0.06)"; e.currentTarget.style.color = "rgba(255,255,255,0.4)" }}
        >✕</button>
      </div>

      {/* Messages */}
      <div style={{
        flex: 1,
        overflowY: "auto",
        display: "flex",
        flexDirection: "column",
        gap: 6,
        padding: "10px 12px",
      }}>
        {msgs.map((m, i) => (
          <div key={i} style={{
            display: "flex",
            gap: 6,
            alignItems: "flex-start",
            flexDirection: m.role === "user" ? "row-reverse" : "row",
          }}>
            <div style={{
              width: 22, height: 22, borderRadius: "50%", flexShrink: 0,
              background: m.role === "assistant" ? "rgba(0,255,136,0.1)" : "rgba(100,100,200,0.12)",
              border: `1px solid ${m.role === "assistant" ? "rgba(0,255,136,0.2)" : "rgba(100,100,200,0.2)"}`,
              display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11,
            }}>{m.role === "assistant" ? "🐰" : "👤"}</div>
            <div style={{
              background: m.role === "assistant" ? "rgba(0,255,136,0.06)" : "rgba(100,100,200,0.08)",
              border: `1px solid ${m.role === "assistant" ? "rgba(0,255,136,0.1)" : "rgba(100,100,200,0.14)"}`,
              borderRadius: 10,
              borderTopLeftRadius: m.role === "assistant" ? 2 : 10,
              borderTopRightRadius: m.role === "user" ? 2 : 10,
              padding: "6px 10px",
              fontSize: "0.75rem",
              color: "rgba(255,255,255,0.82)",
              lineHeight: 1.5,
              maxWidth: "calc(100% - 34px)",
              whiteSpace: "pre-wrap",
              fontFamily: "'Courier New', 'SF Mono', 'Fira Code', monospace",
            }}>{m.content}</div>
          </div>
        ))}
        {loading && (
          <div style={{ display: "flex", gap: 6, alignItems: "flex-start" }}>
            <div style={{ width: 22, height: 22, borderRadius: "50%", background: "rgba(0,255,136,0.1)", border: "1px solid rgba(0,255,136,0.2)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11 }}>🐰</div>
            <div style={{ background: "rgba(0,255,136,0.06)", border: "1px solid rgba(0,255,136,0.1)", borderRadius: 10, borderTopLeftRadius: 2, padding: "7px 12px", display: "flex", gap: 3 }}>
              {[0, 0.18, 0.36].map((d, i) => (
                <div key={i} style={{ width: 4, height: 4, borderRadius: "50%", background: "rgba(0,255,136,0.6)", animation: `bounce 1.2s ${d}s infinite ease-in-out` }} />
              ))}
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div style={{
        display: "flex", gap: 7, alignItems: "center", flexShrink: 0,
        padding: "8px 10px",
        borderTop: "1px solid rgba(0,255,136,0.1)",
        background: "rgba(0,0,0,0.3)",
      }}>
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); void send() } }}
          placeholder="Ask Dr. Rabbit..."
          disabled={loading}
          autoComplete="off"
          style={{
            flex: 1, background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)",
            borderRadius: 8, padding: "7px 10px",
            fontSize: "0.75rem", color: "#fff",
            fontFamily: "'Courier New', 'SF Mono', 'Fira Code', monospace",
            outline: "none",
          }}
        />
        <button
          onClick={() => void send()} disabled={loading || !input.trim()}
          style={{
            width: 30, height: 30, borderRadius: 8,
            background: input.trim() && !loading ? "linear-gradient(135deg, #00ff88, #00cc6a)" : "rgba(255,255,255,0.05)",
            border: "none", cursor: "pointer", display: "flex", alignItems: "center",
            justifyContent: "center", fontSize: "0.78rem", flexShrink: 0,
            transition: "all 0.2s",
            color: input.trim() && !loading ? "#050805" : "rgba(255,255,255,0.25)",
          }}
        >➤</button>
      </div>

      <style>{`
        @keyframes livePulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }
        @keyframes bounce { 0%, 80%, 100% { transform: translateY(0); opacity: 0.4; } 40% { transform: translateY(-5px); opacity: 1; } }
        @keyframes chatWindowIn { from { opacity: 0; transform: translateY(20px) scale(0.95); } to { opacity: 1; transform: translateY(0) scale(1); } }
        @keyframes chatBtnPulse { 0%, 100% { box-shadow: 0 4px 20px rgba(0,255,136,0.15); } 50% { box-shadow: 0 4px 28px rgba(0,255,136,0.3); } }
      `}</style>
    </div>
  )
}

export default function HowItWorksPage() {
  const [, navigate] = useLocation()
  const [visibleStep, setVisibleStep] = useState(-1)
  const [showCta, setShowCta] = useState(false)
  const [chatOpen, setChatOpen] = useState(false)

  useLayoutEffect(() => {
    if ("scrollRestoration" in history) history.scrollRestoration = "manual"
    window.scrollTo(0, 0)
  }, [])

  useEffect(() => {
    const timers: ReturnType<typeof setTimeout>[] = []
    STEPS.forEach((_, i) => {
      const t = setTimeout(() => setVisibleStep(i), 300 + i * 700)
      timers.push(t)
    })
    const ctaTimer = setTimeout(() => setShowCta(true), 300 + STEPS.length * 700 + 400)
    timers.push(ctaTimer)
    return () => timers.forEach(clearTimeout)
  }, [])

  return (
    <>
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet" />
      <CustomCursor />
      <div className="hiw-page-root">
        <div className="ambient-glow ambient-glow-1" />
        <div className="ambient-glow ambient-glow-2" />
        <div className="ambient-glow ambient-glow-3" />

        {/* Top bar */}
        <nav className="hiw-page-nav navbar-visible">
          <div className="nav-content">
            <button className="hiw-back-btn" onClick={() => navigate("/")} type="button">
              <span className="material-icons-outlined">arrow_back</span>
              Back
            </button>
            <div className="logo">
              <span className="material-icons-outlined logo-icon">eco</span>
              <span className="logo-text">MIFTORA EA</span>
            </div>
            <a href="https://instagram.com/mhdkpy" target="_blank" rel="noopener noreferrer" className="btn btn-primary hiw-nav-cta" style={{ padding: "0.55rem 1.2rem", fontSize: "0.88rem" }}>
              <span className="material-icons-outlined">flash_on</span>
              Get Started
              <span className="btn-glow" />
            </a>
          </div>
        </nav>

        <div className="hiw-page-content">
          {/* Header */}
          <div className="hiw-page-header">
            <div className="hiw-page-badge">
              <span className="material-icons-outlined">auto_stories</span>
              Step-by-Step Guide
            </div>
            <h1 className="hiw-page-title">How MIFTORA EA Works</h1>
            <p className="hiw-page-subtitle">4 simple steps to start your halal automated stock trading journey</p>
          </div>

          {/* Steps */}
          <div className="hiw-page-steps">
            {STEPS.map((step, i) => (
              <div
                key={i}
                className={`hiw-page-step ${visibleStep >= i ? "hiw-page-step-in" : ""}`}
              >
                <div className="hiw-page-step-aside">
                  <div className="hiw-page-step-num" style={{ color: step.color }}>{step.number}</div>
                  {i < STEPS.length - 1 && (
                    <div className={`hiw-page-connector ${visibleStep > i ? "hiw-page-connector-lit" : ""}`} />
                  )}
                </div>
                <div className="hiw-page-step-card">
                  <div
                    className="hiw-page-step-ico"
                    style={{
                      background: `linear-gradient(135deg, ${step.color}20, ${step.color}08)`,
                      border: `1px solid ${step.color}30`
                    }}
                  >
                    <span className="material-icons-outlined" style={{ color: step.color, fontSize: 28 }}>{step.icon}</span>
                  </div>
                  <div className="hiw-page-step-body">
                    <h3>{step.title}</h3>
                    <p>{step.desc}</p>
                    <div className="hiw-step-tip">
                      <span className="material-icons-outlined">tips_and_updates</span>
                      {step.detail}
                    </div>
                    {step.link && (
                      <a
                        href={step.link.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="hiw-page-step-link"
                      >
                        <span className="material-icons-outlined">open_in_new</span>
                        {step.link.label}
                      </a>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Dr. Rabbit CTA at bottom */}
          {showCta && (
            <div style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              gap: 10,
              padding: "2rem 1rem 3rem",
              opacity: showCta ? 1 : 0,
              animation: "fadeInUp 0.6s ease",
            }}>
              <p style={{
                color: "rgba(255,255,255,0.45)",
                fontSize: "0.9rem",
                textAlign: "center",
                lineHeight: 1.6,
                maxWidth: 340,
              }}>
                Still confused? Ask our <span style={{ color: "#00ff88", fontWeight: 600 }}>Dr. Rabbit AI</span> — he'll walk you through everything!
              </p>
              {/* Arrow pointing toward bottom-right */}
              <div style={{
                display: "flex",
                alignItems: "center",
                gap: 8,
                color: "rgba(0,255,136,0.5)",
                fontSize: "0.8rem",
              }}>
                <span style={{ letterSpacing: "0.05em" }}>tap the 🐰 in the corner</span>
                <span style={{
                  fontSize: "1.4rem",
                  display: "inline-block",
                  transform: "rotate(45deg)",
                  marginLeft: 2,
                }}>↗</span>
              </div>
            </div>
          )}

        </div>
      </div>

      {/* Floating Dr. Rabbit button */}
      {chatOpen ? (
        <DrRabbitChat onClose={() => setChatOpen(false)} />
      ) : (
        <button
          onClick={() => setChatOpen(true)}
          style={{
            position: "fixed",
            bottom: 20,
            right: 20,
            width: 50,
            height: 50,
            borderRadius: "50%",
            background: "rgba(0,255,136,0.1)",
            border: "1px solid rgba(0,255,136,0.25)",
            backdropFilter: "blur(15px)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: "1.3rem",
            cursor: "pointer",
            zIndex: 10000,
            boxShadow: "0 4px 20px rgba(0,255,136,0.15)",
            transition: "all 0.2s",
            animation: "chatBtnPulse 2s ease-in-out infinite",
          }}
          onMouseEnter={e => { e.currentTarget.style.transform = "scale(1.1)"; e.currentTarget.style.boxShadow = "0 4px 25px rgba(0,255,136,0.3)" }}
          onMouseLeave={e => { e.currentTarget.style.transform = "scale(1)"; e.currentTarget.style.boxShadow = "0 4px 20px rgba(0,255,136,0.15)" }}
          type="button"
        >🐰</button>
      )}

      <style>{`
        @keyframes chatBtnPulse { 0%, 100% { box-shadow: 0 4px 20px rgba(0,255,136,0.15); } 50% { box-shadow: 0 4px 28px rgba(0,255,136,0.3); } }
        @keyframes fadeInUp { from { opacity: 0; transform: translateY(16px); } to { opacity: 1; transform: translateY(0); } }
      `}</style>
    </>
  )
}
