import { useState } from "react"
import { Switch, Route } from "wouter"
import Index from "@/pages/Index"
import HowItWorksPage from "@/pages/HowItWorksPage"
import ConsultDoctorAI from "@/pages/ConsultDoctorAI"
import LoadingScreen from "@/components/LoadingScreen"
import OnboardingQuiz from "@/components/OnboardingQuiz"
import NetworkGuard from "@/components/NetworkGuard"

function NotFound() {
  return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "#050805", color: "#00ff88", fontFamily: "Inter, sans-serif", textAlign: "center" }}>
      <div>
        <h1 style={{ fontSize: "4rem", fontWeight: 800, marginBottom: "1rem" }}>404</h1>
        <p style={{ color: "rgba(255,255,255,0.6)", marginBottom: "2rem" }}>Page not found</p>
        <a href="/" style={{ color: "#00ff88", textDecoration: "none", border: "1px solid rgba(0,255,136,0.3)", padding: "0.75rem 1.5rem", borderRadius: "10px" }}>Go Home</a>
      </div>
    </div>
  )
}

type Stage = "loading" | "quiz" | "app"

function App() {
  const [stage, setStage] = useState<Stage>("loading")

  const handleLoadingDone = () => setStage("quiz")
  const handleQuizDone = () => setStage("app")

  return (
    <>
      <NetworkGuard />

      {stage === "loading" && (
        <LoadingScreen onComplete={handleLoadingDone} />
      )}

      {stage === "quiz" && (
        <OnboardingQuiz onComplete={handleQuizDone} />
      )}

      {stage === "app" && (
        <>
          <Switch>
            <Route path="/" component={Index} />
            <Route path="/how-it-works" component={HowItWorksPage} />
            <Route path="/consult-doctor-ai" component={ConsultDoctorAI} />
            <Route component={NotFound} />
          </Switch>
        </>
      )}
    </>
  )
}

export default App
