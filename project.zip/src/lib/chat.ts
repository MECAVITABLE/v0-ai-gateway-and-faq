export interface ChatTurn {
  role: "user" | "assistant"
  content: string
}

interface SendChatOptions {
  system: string
  messages: ChatTurn[]
  maxTokens?: number
  temperature?: number
}

export const FOUNDERS_BLURB = `The creators / founders of MIFTORA EA are three friends from Kerala, India:
- Muhammad Najih (@m.najey on Instagram) — trader and co-founder.
- Muhammed KP (@mhdkpy on Instagram) — co-founder.
- Aslam (@m_asluu_t.x on Instagram) — co-creator of MIFTORA EA.
If anyone asks who Aslam is, say he is one of the creators of MIFTORA EA, together with Najih and Muhammed KP, and share his Instagram handle @m_asluu_t.x.`

export const PRODUCT_BLURB = `About MIFTORA EA:
- MIFTORA EA is a halal EA (Expert Advisor / trading bot) HOSTING service for the stock market. It is NOT forex and NOT copy trading.
- Users bring their own EA and their own account at a Shariah-compliant stock broker. MIFTORA hosts the EA on secure, always-on servers (24/7 uptime) so the user does not need to keep a PC running. The EA trades during stock market hours.
- Funds always stay in the user's own broker account. MIFTORA never holds user money.
- Halal approach: cash (non-margin) account only, no leverage, no borrowing, no interest (riba) or swap fees, no short selling, and only Shariah-screened stocks (no alcohol, gambling, pork, adult content, conventional interest-based finance, etc.).
- Transparency: users can review the logs and reports of every trade their EA makes.
- Getting started: 1) open a cash account with a Shariah-compliant stock broker, 2) fund it with an amount you can afford to lose, 3) contact the MIFTORA team to set up your EA on our hosting, 4) monitor your EA and reports.

Important rules for answers:
- Never promise or guarantee profits. All trading, including stocks, carries risk of loss.
- Do not issue religious rulings (fatwa). Explain the halal approach above, and tell users to confirm with a qualified scholar if they want certainty.
- Do not mention forex, Exness, Myfxbook, MetaTrader, copy trading, pips or currency pairs as things MIFTORA offers.
- For setup, pricing or support questions, direct users to the founders on Instagram.`

export async function sendChat({ system, messages, maxTokens, temperature }: SendChatOptions): Promise<string> {
  const response = await fetch("/api/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      messages: [{ role: "system", content: system }, ...messages],
      maxTokens,
      temperature,
    }),
  })

  if (!response.ok) {
    throw new Error(`Chat request failed with status ${response.status}`)
  }

  const data = (await response.json()) as { content?: string }
  return data.content?.trim() ?? ""
}
