import { forwardChat } from "../server/chatProxy"

export async function POST(request: Request): Promise<Response> {
  let payload: unknown
  try {
    payload = await request.json()
  } catch {
    return Response.json({ error: "Invalid JSON." }, { status: 400 })
  }

  const { status, body } = await forwardChat(payload)
  return Response.json(body, { status })
}
