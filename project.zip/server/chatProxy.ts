const GEMINI_MODELS = ["gemini-2.5-flash-lite", "gemini-3.1-flash-lite", "gemini-flash-latest", "gemini-3.5-flash"]
const HEDGE_DELAY_MS = 2000
const TOTAL_TIMEOUT_MS = 25000
const geminiUrl = (model: string) => `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`

interface ChatMessage {
  role: "system" | "user" | "assistant"
  content: string
}

export interface ChatResult {
  status: number
  body: { content?: string; error?: string }
}

interface GeminiResponse {
  candidates?: { content?: { parts?: { text?: string }[] } }[]
  error?: { message?: string }
}

function isChatMessage(value: unknown): value is ChatMessage {
  if (!value || typeof value !== "object") return false
  const { role, content } = value as Record<string, unknown>
  return (
    (role === "system" || role === "user" || role === "assistant") &&
    typeof content === "string" &&
    content.length <= 4000
  )
}

export async function forwardChat(payload: unknown): Promise<ChatResult> {
  const apiKey = process.env.GOOGLE_API_KEY || process.env.GEMINI_API_KEY
  if (!apiKey) {
    return { status: 500, body: { error: "AI is not configured." } }
  }

  const { messages, maxTokens, temperature } = (payload ?? {}) as {
    messages?: unknown
    maxTokens?: unknown
    temperature?: unknown
  }

  if (!Array.isArray(messages) || messages.length === 0 || messages.length > 40 || !messages.every(isChatMessage)) {
    return { status: 400, body: { error: "Invalid messages." } }
  }

  const safeMaxTokens = typeof maxTokens === "number" ? Math.min(Math.max(Math.floor(maxTokens), 16), 600) : 300
  const safeTemperature = typeof temperature === "number" ? Math.min(Math.max(temperature, 0), 1.2) : 0.7

  const system = messages
    .filter((message) => message.role === "system")
    .map((message) => message.content)
    .join("\n\n")
  const conversation = messages.filter((message) => message.role !== "system")

  if (conversation.length === 0) {
    return { status: 400, body: { error: "Invalid messages." } }
  }

  const requestBody = JSON.stringify({
    systemInstruction: system ? { parts: [{ text: system }] } : undefined,
    contents: conversation.map((message) => ({
      role: message.role === "assistant" ? "model" : "user",
      parts: [{ text: message.content }],
    })),
    generationConfig: {
      maxOutputTokens: safeMaxTokens,
      temperature: safeTemperature,
      thinkingConfig: { thinkingBudget: 0 },
    },
  })

  const askModel = async (model: string, signal: AbortSignal): Promise<string> => {
    const response = await fetch(geminiUrl(model), {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": apiKey },
      body: requestBody,
      signal,
    })
    const data = (await response.json()) as GeminiResponse
    if (!response.ok) throw new Error(`${model} ${response.status}: ${data.error?.message ?? "request failed"}`)
    const text = (data.candidates?.[0]?.content?.parts ?? []).map((part) => part.text ?? "").join("").trim()
    if (!text) throw new Error(`${model} returned an empty reply`)
    return text
  }

  // Gemini free-tier models intermittently hang or return 503, so a backup model
  // is started if the previous one has not answered within HEDGE_DELAY_MS.
  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), TOTAL_TIMEOUT_MS)
  const attempts = GEMINI_MODELS.map(async (model, index) => {
    await new Promise((resolve) => setTimeout(resolve, index * HEDGE_DELAY_MS))
    if (controller.signal.aborted) throw new Error("aborted")
    return askModel(model, controller.signal)
  })

  try {
    const text = await Promise.any(attempts)
    return { status: 200, body: { content: text } }
  } catch (error) {
    const reasons = error instanceof AggregateError ? error.errors.map((e) => (e as Error).message) : [String(error)]
    console.error("Gemini request failed:", reasons.join(" | "))
    return { status: 502, body: { error: "Could not reach the AI service." } }
  } finally {
    clearTimeout(timeout)
    controller.abort()
  }
}
